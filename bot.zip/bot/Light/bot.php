<?php

error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
$configFile = "config.json";

// Warna ANSI ala Hacker
const hitam  = "\033[0;30m";
const merah  = "\033[1;31m";
const hijau  = "\033[1;32m";
const kuning = "\033[1;33m";
const biru   = "\033[1;34m";
const cyan   = "\033[1;36m";
const putih  = "\033[1;37m";
const putih_redup = "\033[0;37m";
const reset  = "\033[0m";
const bold   = "\033[1m";

const api_url           = "https://lightningquest.net";
const solver_in         = "https://api.waryono.my.id/in.php";
const solver_out        = "https://api.waryono.my.id/res.php";
const SITEKEY_HCAPTCHA  = "bbc4e0f2-0052-4980-b1c2-aafe3e3c3bee";
const SITEKEY_TURNSTILE = "0x4AAAAAADxePtT-Imsq_y0B";

function clear() {
    (PHP_OS == "Linux") ? system('clear') : pclose(popen('cls', 'w'));
}

function typewrite($text, $speed = 0.015) {
    for ($i = 0; $i < mb_strlen($text); $i++) {
        echo mb_substr($text, $i, 1);
        flush();
        usleep($speed * 1000000);
    }
    echo "\n";
}

function hacker_intro() {
    clear();
    echo hijau;
    typewrite("[+] Initializing LightningQuest Protocol...", 0.015);
    typewrite("[+] Bypassing security...", 0.015);
    typewrite("[+] System Ready & Online!", 0.015);
    echo reset;
    sleep(1);
}

function banner() {
    $t1 = "    LIGHTNINGQUEST AUTO CLAIM BOT   ";
    $t2 = "    Modified by AnbuKASKUS    ";
    $t3 = " Credit to : SKIBIDIXXX | API Waryono";
    
    $max_len = max(mb_strlen($t1), mb_strlen($t2), mb_strlen($t3));
    $border = str_repeat("─", $max_len + 2);
    
    echo cyan . "\n  ╭{$border}╮\n";
    echo "  │ " . kuning . bold . str_pad($t1, $max_len, " ", STR_PAD_BOTH) . cyan . " │\n";
    echo "  │ " . kuning . str_pad($t2, $max_len, " ", STR_PAD_BOTH) . cyan . " │\n";
    echo "  │ " . merah . str_pad($t3, $max_len, " ", STR_PAD_BOTH) . cyan . " │\n";
    echo "  ╰{$border}╯\n\n" . reset;
}

// Prefix putih, progress bar menggunakan warna putih redup
function timer($seconds, $prefix = "⏳ Starting claiim") {
    $total_blocks = 10;
    $sec = (int)$seconds;
    if ($sec < 1) $sec = 1;
    
    for ($i = 0; $i <= $sec; $i++) {
        $progress = ($sec > 0) ? ($i / $sec) : 1;
        $num_blocks = (int)($progress * $total_blocks);
        $bar = str_repeat("■", $num_blocks) . str_repeat(" ", $total_blocks - $num_blocks);
        $percent = (int)($progress * 100);
        
        echo "\r" . putih . "$prefix " . putih_redup . "[$bar] $percent%" . reset;
        flush();
        
        if ($i < $sec) {
            sleep(1);
        }
    }
    echo "\r                                                       \r";
}

function getConfig($configFile) {
    if (!file_exists($configFile)) {
        echo putih . "API Key (captcha) : " . kuning;
        $apikey = trim(fgets(STDIN));
        echo putih . "Email     : " . kuning;
        $email = trim(fgets(STDIN));
        echo putih . "Password  : " . kuning;
        $password = trim(fgets(STDIN));
        $data = [
            "apikey"   => $apikey,
            "email"    => $email,
            "password" => $password
        ];
        file_put_contents($configFile, json_encode($data, JSON_PRETTY_PRINT));
        echo hijau . "Konfigurasi disimpan ke $configFile\n\n" . reset;
        sleep(2);
        return $data;
    }
    return json_decode(file_get_contents($configFile), true);
}

function wkwk($url, $payload = null, $headers = [], $method = "POST") {
    while (true) {
        $ch = curl_init();
        $final = [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYHOST => 1,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_CONNECTTIMEOUT => 999,
            CURLOPT_TIMEOUT        => 999,
            CURLOPT_COOKIEFILE     => 'cookies.txt',
            CURLOPT_COOKIEJAR      => 'cookies.txt'
        ];
        if ($method === "POST") {
            $final[CURLOPT_POST] = true;
            $final[CURLOPT_POSTFIELDS] = json_encode($payload);
        }
        curl_setopt_array($ch, $final);
        $response = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($response) {
            return ["body" => $response, "code" => $code];
        }
        echo putih . "\nwiwok detok, retry...\n";
        sleep(2);
    }
}

function solve_captcha($apikey, $method, $sitekey, $action = "") {
    $headers = ["Content-Type: application/json"];
    $body = [
        "apikey"  => $apikey,
        "methods" => $method,
        "domain"  => "https://lightningquest.net",
        "sitekey" => $sitekey,
        "json"    => 1
    ];
    if ($action !== "") {
        $body["action"] = $action;
        $body["cdata"] = "";
    }
    $request = wkwk(solver_in, $body, $headers);
    $request = $request["body"];
    foreach (["ERROR_WRONG_METHOD", "ERROR_KEY_DOES_NOT_EXIST", "ERROR_METHOD_NOT_SPECIFIED", "ERROR_NO_SUCH_METHOD", "ERROR_DATABASE_CONNECTION_FAILED", "ERROR_WRONG_USER_KEY", "ERROR_ZERO_BALANCE", "ERROR_BAD_PARAMETERS", "ERROR_EMPTY_IMAGE", "ERROR_UNKNOWN"] as $e) {
        if (strpos($request, $e) !== false) {
            echo putih . "Error: " . merah . $e . "\n";
            exit;
        }
    }
    if (strpos($request, "ERROR_TOO_MANY_REQUESTS") !== false) {
        echo putih . "Error: " . merah . "ERROR_TOO_MANY_REQUESTS";
        sleep(2);
        echo "\r                                       \r";
        return solve_captcha($apikey, $method, $sitekey, $action);
    }
    $json = json_decode($request, true);
    $id = $json["request"];

    reload:
    timer(5, "  $method... ");
    $res = wkwk(solver_out . "?apikey=" . $apikey . "&action=get&id=" . $id . "&json=1", null, [], "GET");
    $result = $res["body"];

    foreach (["ERROR_BAD_PARAMETERS", "Database connection failed"] as $e) {
        if (strpos($result, $e) !== false) {
            echo putih . "Error: " . merah . $e . "\n";
            exit;
        }
    }
    if (strpos($result, "WRONG_CAPTCHA_ID") !== false || strpos($result, "ERROR_SOLVE_PENDING") !== false) {
        echo putih . "Error: " . merah . "WRONG_CAPTCHA_ID / PENDING";
        sleep(1.5);
        echo "\r                                       \r";
        return solve_captcha($apikey, $method, $sitekey, $action);
    }
    if (strpos($result, "CAPCHA_NOT_READY") !== false) {
        goto reload;
    }
    if (strpos($result, "ERROR_CAPTCHA_UNSOLVABLE") !== false) {
        echo putih . "Error: " . merah . "ERROR_CAPTCHA_UNSOLVABLE";
        sleep(1.5);
        echo "\r                                       \r";
        return solve_captcha($apikey, $method, $sitekey, $action);
    }
    if (strpos($result, "ERROR_BAD_REQUEST") !== false || strpos($result, "INTENAL_SERVER_ERROR") !== false) {
        echo putih . "Error: " . merah . "solver error";
        sleep(1.5);
        echo "\r                                       \r";
        return solve_captcha($apikey, $method, $sitekey, $action);
    }
    $json = json_decode($result, true);
    return $json["request"];
}

// Inisialisasi Tampilan Awal ala Python Script
hacker_intro();
banner();

$config   = getConfig($configFile);
$apikey   = $config['apikey'];
$email    = $config['email'];
$password = $config['password'];

$access_token = '';

function auth_headers() {
    global $access_token;
    $h = [
        'sec-ch-ua: "Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
        'sec-ch-ua-platform: "Android"',
        'sec-ch-ua-mobile: ?1',
        'user-agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36',
        'content-type: application/json',
        'accept: */*',
        'origin: https://lightningquest.net',
        'sec-fetch-site: same-origin',
        'sec-fetch-mode: cors',
        'sec-fetch-dest: empty',
        'referer: https://lightningquest.net/faucet',
        'accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
        'priority: u=1, i'
    ];
    if ($access_token) {
        $h[] = 'authorization: Bearer ' . $access_token;
    }
    return $h;
}

function do_login($email, $password) {
    $body = [
        "email" => $email,
        "password" => $password,
        "trafficExchangeBonus" => false
    ];
    $res = wkwk(api_url . "/api/auth/login", $body, auth_headers());
    $json = json_decode($res["body"], true);
    if (!empty($json['access_token'])) {
        return $json;
    }
    echo putih . "[LOGIN] " . merah . ($json['msg'] ?? $json['message'] ?? $res['body']) . "\n";
    exit;
}

function api_get($path) {
    global $email, $password, $access_token;
    $res = wkwk(api_url . $path, null, auth_headers(), "GET");
    if ($res["code"] == 401) {
        echo putih . "[AUTH] " . kuning . "Token expired, login ulang...\n";
        $login = do_login($email, $password);
        $access_token = $login['access_token'];
        $res = wkwk(api_url . $path, null, auth_headers(), "GET");
    }
    return json_decode($res["body"], true);
}

function api_post($path, $payload) {
    global $email, $password, $access_token;
    $res = wkwk(api_url . $path, $payload, auth_headers());
    if ($res["code"] == 401) {
        echo putih . "[AUTH] " . kuning . "Token expired, login ulang...\n";
        $login = do_login($email, $password);
        $access_token = $login['access_token'];
        $res = wkwk(api_url . $path, $payload, auth_headers());
    }
    return json_decode($res["body"], true);
}

function pretty_num($v) {
    if (is_array($v)) {
        if (isset($v['current']) || isset($v['value'])) {
            return pretty_num($v['current'] ?? $v['value']);
        }
        foreach ($v as $sub) {
            if (is_numeric($sub)) {
                return $sub;
            }
        }
        return json_encode($v);
    }
    return $v;
}

typewrite(cyan . "🔑 Logging in..." . reset, 0.015);
$login = do_login($email, $password);
$access_token = $login['access_token'];
$username = $login['user']['username'] ?? $login['user']['email'] ?? $email;
typewrite(hijau . "✅ Logged in successfully!" . reset, 0.015);

echo putih . " Account : " . kuning . $email . reset . "\n\n";

$me = api_get("/api/me");
if (!empty($me)) {
    if (isset($me['username']) || isset($me['name'])) {
        $username = $me['username'] ?? $me['name'] ?? $username;
    }
    if (isset($me['balance']) || isset($me['coins']) || isset($me['xp']) || isset($me['level'])) {
        echo putih . "user: " . cyan . $username . putih . " | balance: " . hijau . pretty_num($me['balance'] ?? $me['coins'] ?? '?') . putih . " | xp: " . hijau . pretty_num($me['xp'] ?? '?') . putih . " | level: " . hijau . pretty_num($me['level'] ?? '?') . "\n";
    } else {
        echo putih . "user: " . cyan . $username . "\n";
    }
} else {
    echo putih . "user: " . cyan . $username . "\n";
}

typewrite("\n" . hijau . "🔄 Starting Automated Loop..." . reset, 0.015);
echo kuning . "──────────────────────────────────────────────────\n" . reset;

$claims_done = 0;
$total_earned_coins = 0.0;

while (true) {
    echo "\n";
    $status = api_get("/api/claim-status");
    if (!isset($status['faucet'])) {
        echo putih . "[STATUS] " . merah . json_encode($status) . "\n";
        timer(30, "⏳ retry...");
        continue;
    }
    $faucet = $status['faucet'];
    $ready  = $faucet['ready'] ?? false;
    $captchaRequired = $faucet['captchaRequired'] ?? false;
    $provider = $faucet['captchaProvider'] ?? 'hcaptcha';

    $daily = $status['daily'] ?? [];
    if (!empty($daily['ready']) && !empty($daily['firstClaim'])) {
        echo putih . "[DAILY] " . kuning . "first claim tersedia, claim...\n";
        $dres = api_post("/api/claim/daily", new stdClass());
        if (!empty($dres['ok'])) {
            $drew = $dres['reward'] ?? [];
            echo putih . "[DAILY] " . hijau . "+" . ($drew['coins'] ?? 0) . " coins, +" . ($drew['xp'] ?? 0) . " xp\n";
        } else {
            echo putih . "[DAILY] " . merah . json_encode($dres) . "\n";
        }
    }

    if (!$ready) {
        $nextAt = strtotime($faucet['nextAt'] ?? '');
        $cd = intval($faucet['cooldownSeconds'] ?? 300);
        $wait = $nextAt ? ($nextAt - time()) : $cd;
        if ($wait < 5) {
            $wait = 5;
        }
        timer($wait, "⏳ Starting claiim");
        continue;
    }

    echo putih . "[STATUS] READY | captcha: " . biru . ($captchaRequired ? "yes(" . $provider . ")" : "no") . "\n";

    $ch = api_get("/api/faucet/challenge");
    if (empty($ch['claimToken'])) {
        echo putih . "[CHALLENGE] " . merah . json_encode($ch) . "\n";
        timer(15, "⏳ retry...");
        continue;
    }
    $claimToken = $ch['claimToken'];
    $minWait = intval($ch['minWaitSeconds'] ?? 0);
    if ($minWait > 0) {
        timer($minWait, "⏳ Proses bypass..");
    }

    $captchaToken = "";
    if ($captchaRequired) {
        if ($provider === "hcaptcha") {
            $captchaToken = solve_captcha($apikey, "hcaptcha", SITEKEY_HCAPTCHA);
        } else {
            $captchaToken = solve_captcha($apikey, "turnstile", SITEKEY_TURNSTILE, "faucet-cadence-v1");
        }
        if (!$captchaToken) {
            continue;
        }
    }

    echo kuning . "[claim/faucet]" . reset . "\n";
    $claim = api_post("/api/claim/faucet", [
        "captchaToken" => $captchaToken,
        "claimToken"   => $claimToken
    ]);
    
    if (empty($claim['ok'])) {
        echo putih . "[CLAIM] " . merah . json_encode($claim) . "\n";
        timer(15, "⏳ retry...");
        continue;
    }
    
    $claims_done++;
    $reward = $claim['reward'] ?? [];
    $coins_gained = $reward['coins'] ?? 0;
    $total_earned_coins += $coins_gained;
    $snap = $reward['snapshot'] ?? $claim['snapshot'] ?? [];
    
    echo hijau . "✅ Success! " . kuning . "★★★★★" . reset . "\n";
    echo hijau . "💎 Reward +" . $coins_gained . " coins, +" . ($reward['xp'] ?? 0) . " xp" . reset . "\n";
    echo putih . "📊 Total: $claims_done claims | Balance: " . hijau . ($snap['balance'] ?? '?') . putih . " | xp: " . hijau . ($snap['xp'] ?? '?') . putih . " | level: " . hijau . ($snap['level'] ?? '?') . reset . "\n";
    echo kuning . "──────────────────────────────────────────────────" . reset . "\n";

    $nextAt = strtotime($claim['nextAt'] ?? '');
    $cooldown = $nextAt ? ($nextAt - time()) : 300;
    if ($cooldown < 5) {
        $cooldown = 300;
    }
    timer($cooldown + mt_rand(2, 5), "⏳ Starting claiim");
}
