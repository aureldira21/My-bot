#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__OWN__ = "ScriptyXSouu Style"
__OBF__ = ""
__USR__ = "Cool Sentinel Client Protection Layer"
__MSG__ = "Nice try to decode it"

import requests
import time
import json
import re
import os
from datetime import datetime

# ============ KONFIGURASI ============
BASE_URL = "https://app.dogenetwork.online"
INTERVAL = 3600  # 1 jam

# ============ WARNA ============
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    RESET = '\033[0m'
    GOLD = '\033[38;5;220m'
    ORANGE = '\033[38;5;208m'
    PURPLE = '\033[38;5;129m'
    WHITE = '\033[97m'

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def save_cookies(cookies):
    try:
        with open('cookies.json', 'w') as f:
            json.dump(cookies, f, indent=2)
    except:
        pass

def load_cookies():
    try:
        if os.path.exists('cookies.json'):
            with open('cookies.json', 'r') as f:
                return json.load(f)
    except:
        pass
    return None

def type_text(text, delay=0.01):
    """Fungsi untuk animasi teks berjalan (typing effect)"""
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print()

# ============================================================
# ====================== BANNER ==============================
# ============================================================

def banner():
    print(f"""{Colors.GOLD}
██████╗  ██████╗  ██████╗ ███████╗
██╔══██╗██╔═══██╗██╔════╝ ██╔════╝
██║  ██║██║   ██║██║  ███╗█████╗  
██║  ██║██║   ██║██║   ██║██╔══╝  
██████╔╝╚██████╔╝╚██████╔╝███████╗
╚═════╝  ╚═════╝  ╚═════╝ ╚══════╝
{Colors.RESET}""")
    type_text(f"{Colors.GOLD}https://t.me/gratisancryp{Colors.RESET}", 0.02)
    type_text(f"{Colors.WHITE}Credit to Garapan Crypto Gratis{Colors.RESET}", 0.02)
    type_text(f"{Colors.WHITE}=============================={Colors.RESET}", 0.01)

# ============================================================
# ====================== SESSION =============================
# ============================================================

session = requests.Session()
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    'Accept': '*/*',
    'Referer': 'https://app.dogenetwork.online/dashboard',
    'Origin': 'https://app.dogenetwork.online',
    'Content-Type': 'application/json',
    'X-Requested-With': 'XMLHttpRequest'
}
session.headers.update(HEADERS)

# ============================================================
# ====================== FUNGSI ==============================
# ============================================================

def check_session():
    try:
        resp = session.get(f"{BASE_URL}/dashboard")
        return resp.status_code == 200 and 'Control Center' in resp.text
    except:
        return False

def get_csrf_token():
    try:
        resp = session.get(f"{BASE_URL}/dashboard")
        if resp.status_code == 200:
            match = re.search(r'<meta name="csrf-token"[^>]*content="([^"]+)"', resp.text)
            if match:
                return match.group(1)
        return None
    except:
        return None

def extract_captcha(svg):
    numbers = re.findall(r'<text[^>]*>(\d)</text>', svg)
    if len(numbers) >= 4:
        return ''.join(numbers[:4])
    match = re.search(r'(\d{4})', svg)
    if match:
        return match.group(1)
    return None

def get_captcha():
    try:
        csrf = get_csrf_token()
        if csrf:
            session.headers.update({'X-CSRF-TOKEN': csrf})
        
        resp = session.get(f"{BASE_URL}/captcha")
        if resp.status_code == 200:
            data = resp.json()
            if data.get('success'):
                svg = data.get('svg', '')
                captcha = extract_captcha(svg)
                if captcha:
                    return captcha
        return None
    except:
        return None

def claim_mining(captcha):
    try:
        csrf = get_csrf_token()
        if csrf:
            session.headers.update({'X-CSRF-TOKEN': csrf})
        
        resp = session.post(f"{BASE_URL}/claim", json={"captcha": str(captcha)})
        if resp.status_code == 200:
            result = resp.json()
            msg = result.get('message', '')
            msg = re.sub(r'\s+to your account balance', '', msg, flags=re.IGNORECASE)
            return result.get('success', False), msg
        else:
            try:
                result = resp.json()
                msg = result.get('message', f'HTTP {resp.status_code}')
                msg = re.sub(r'\s+to your account balance', '', msg, flags=re.IGNORECASE)
                return False, msg
            except:
                return False, f'HTTP {resp.status_code}'
    except Exception as e:
        return False, str(e)

def check_balance():
    try:
        resp = session.get(f"{BASE_URL}/dashboard")
        if resp.status_code == 200:
            html = resp.text
            match = re.search(r'header-balance-amount["\']?>([\d.]+)', html)
            if match:
                return match.group(1)
            match = re.search(r'id="balance"[^>]*>([\d.]+)', html)
            if match:
                return match.group(1)
        return None
    except:
        return None

def progress_bar(seconds):
    """Progress bar menggunakan format carriage return (\r) agar diam di satu baris"""
    for i in range(seconds, 0, -1):
        progress = ((seconds - i) / seconds) * 100
        bar_length = 20
        filled = int(bar_length * progress / 100)
        bar = "=" * filled + " " * (bar_length - filled)
        
        hours = i // 3600
        minutes = (i % 3600) // 60
        secs = i % 60
        
        if hours > 0:
            time_str = f"{hours}j {minutes}m {secs}d"
        elif minutes > 0:
            time_str = f"{minutes}m {secs}d"
        else:
            time_str = f"{secs}d"
        
        print(f"\r{Colors.YELLOW}⏳{Colors.RESET} [{Colors.GREEN}{bar}{Colors.RESET}] {progress:.1f}% | Sisa: {time_str}   ", end='', flush=True)
        time.sleep(1)
    print()

# ============================================================
# ====================== MAIN ================================
# ============================================================

def main():
    clear_screen()
    banner()
    
    cookies = load_cookies()
    if cookies:
        print(f"{Colors.BLUE}📂 Cookies ditemukan!{Colors.RESET}")
        session.cookies.update(cookies)
        
        if check_session():
            print(f"{Colors.GREEN}✅ Session valid! Langsung mulai mining...{Colors.RESET}")
            start_mining()
            return
        else:
            print(f"{Colors.RED}⚠️ Session expired! Masukkan ulang.{Colors.RESET}\n")
    
    email = input(f"{Colors.CYAN}📧 Email FaucetPay: {Colors.RESET}").strip()
    if not email:
        print(f"{Colors.RED}❌ Email wajib diisi!{Colors.RESET}")
        return
    
    print(f"\n{Colors.YELLOW}📋 Paste cookies dari browser:{Colors.RESET}")
    
    cookie_string = input(f"{Colors.CYAN}🍪 Cookies: {Colors.RESET}").strip()
    if not cookie_string:
        print(f"{Colors.RED}❌ Cookies wajib diisi!{Colors.RESET}")
        return
    
    cookies = {}
    for item in cookie_string.split(';'):
        item = item.strip()
        if '=' in item:
            name, value = item.split('=', 1)
            cookies[name.strip()] = value.strip()
    
    if not cookies:
        print(f"{Colors.RED}❌ Format cookies salah!{Colors.RESET}")
        return
    
    session.cookies.update(cookies)
    save_cookies(cookies)
    
    print(f"\n{Colors.YELLOW}🔍 Verifikasi login...{Colors.RESET}")
    if check_session():
        print(f"{Colors.GREEN}✅ Login BERHASIL! Email: {email}{Colors.RESET}")
        start_mining()
    else:
        print(f"{Colors.RED}❌ Login GAGAL! Cookies mungkin expired{Colors.RESET}")

def start_mining():
    clear_screen()
    banner()
    print(f"{Colors.GOLD}  ⛏️  MINING DOGECOIN ACTIVE{Colors.RESET}")
    print(f"{Colors.WHITE}=============================={Colors.RESET}")
    
    cycle = 0
    success = 0
    failed = 0
    
    while True:
        cycle += 1
        print(f"{Colors.BLUE}[{datetime.now().strftime('%H:%M:%S')}]{Colors.RESET} {Colors.BOLD}🔄 Siklus #{cycle}{Colors.RESET}")
        
        balance = check_balance()
        if balance:
            print(f"{Colors.YELLOW}💰 Balance: {balance} DOGE{Colors.RESET}")
        
        print(f"{Colors.CYAN}📷 Mengambil captcha...{Colors.RESET}")
        captcha = get_captcha()
        if not captcha:
            print(f"{Colors.RED}⏳ Gagal ambil captcha, coba lagi 10s{Colors.RESET}")
            time.sleep(10)
            continue
        
        print(f"{Colors.GREEN}📷 Captcha: {captcha}{Colors.RESET}")
        
        success_status, message = claim_mining(captcha)
        if success_status:
            success += 1
            print(f"{Colors.GREEN}✅ {message}{Colors.RESET}")
            time.sleep(2)
            balance = check_balance()
            if balance:
                print(f"{Colors.GOLD}💰 Balance baru: {balance} DOGE{Colors.RESET}")
        else:
            failed += 1
            print(f"{Colors.RED}❌ {message}{Colors.RESET}")
        
        print(f"{Colors.YELLOW}⏳ Tunggu 1 jam...{Colors.RESET}")
        progress_bar(INTERVAL)
        print(f"{Colors.GREEN}✅ Waktu tunggu selesai!{Colors.RESET}")
        print(f"{Colors.WHITE}=============================={Colors.RESET}\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{Colors.RED}[{datetime.now().strftime('%H:%M:%S')}] 🛑 Bot berhenti{Colors.RESET}")
    except Exception as e:
        print(f"\n{Colors.RED}❌ Error: {e}{Colors.RESET}")
