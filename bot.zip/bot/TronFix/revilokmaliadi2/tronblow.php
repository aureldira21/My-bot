<?php
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');

// ======================= KONFIGURASI =======================
$CONFIG_FILE   = __DIR__ . "/tronblow_config.json";
$COOKIE_FILE   = __DIR__ . "/cookies_tronblow.txt";
$LAST_RESPONSE = __DIR__ . "/last_response.html";

$UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36';

// ======================= WARNA =======================
const GOLD     = "\033[38;5;220m";
const L_GOLD   = "\033[1;33m";
const GREEN    = "\033[1;32m";
const CYAN     = "\033[1;36m";
const RED      = "\033[1;31m";
const WHITE    = "\033[1;37m";
const ORANGE   = "\033[38;5;208m";
const L_ORANGE = "\033[1;38;5;208m";
const RESET    = "\033[0m";
const BOLD     = "\033[1m";

// ======================= FUNGSI UI =======================
function typewrite($text, $speed = 15000) {
    $length = mb_strlen($text);
    for ($i = 0; $i < $length; $i++) {
        echo mb_substr($text, $i, 1);
        @ob_flush(); @flush();
        usleep($speed);
    }
    echo "\n";
}

function clear() {
    (PHP_OS == "Linux") ? system('clear') : pclose(popen('cls', 'w'));
}

function hacker_intro() {
    clear();
    echo "\n" . GREEN;
    typewrite("[+] Initializing TronBlow Protocol...", 15000);
    typewrite("[+] Bypassing security...", 15000);
    typewrite("[+] System Ready & Online!", 15000);
    echo RESET . "\n";
}

function banner() {
    clear();
    
    echo "\n";
    echo L_ORANGE . BOLD;
    echo "   ████████╗██████╗  ██████╗ ███╗   ██╗\n";
    echo "   ╚══██╔══╝██╔══██╗██╔═══██╗████╗  ██║\n";
    echo "      ██║   ██████╔╝██║   ██║██╔██╗ ██║\n";
    echo "      ██║   ██╔══██╗██║   ██║██║╚██╗██║\n";
    echo "      ██║   ██║  ██║╚██████╔╝██║ ╚████║\n";
    echo "      ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝\n";
    echo RESET;
    
    echo ORANGE . "              B L O W\n" . RESET;
    echo "\n";
    echo WHITE . "      Fix claim by " . L_ORANGE . "Jendela Semesta" . RESET . "\n";
    echo ORANGE . "      https://t.me/jendelasemesta" . RESET . "\n";
    echo "\n";
    echo ORANGE . "  ─────────────────────────────────────" . RESET . "\n\n";
}

function timer($seconds, $text = "Next claim") {
    $frames = [
        "01010101010101010101",
        "10101010101010101010",
        "11001100110011001100",
        "00110011001100110011",
        "10011001100110011001",
        "01100110011001100110",
        "10100101101001011010",
        "01011010010110100101",
    ];
    
    $start = time();
    $i = 0;
    
    while (time() - $start < $seconds) {
        $remaining = $seconds - (time() - $start);
        echo "\r" . WHITE . $text . " (" . $remaining . "s) " . GREEN . $frames[$i % count($frames)] . RESET;
        usleep(150000);
        $i++;
    }
    echo "\r" . GREEN . "✓ Siap claim lagi!" . str_repeat(" ", 40) . RESET . "\n";
}

// ======================= FUNGSI BOT =======================
function fetch_page($url, $cookie_file, $ua) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_COOKIEJAR      => $cookie_file,
        CURLOPT_COOKIEFILE     => $cookie_file,
        CURLOPT_USERAGENT      => $ua,
        CURLOPT_HTTPHEADER     => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language: en-US,en;q=0.9',
            'Cache-Control: no-cache',
            'Pragma: no-cache',
        ],
    ]);
    $html = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['html' => $html ?: '', 'code' => $code];
}

function extract_csrf_token(string $html): ?string {
    if (preg_match('/name=["\']csrf_token["\']\s+value=["\']([^"\']+)["\']/i', $html, $m)) {
        return $m[1];
    }
    if (preg_match('/name=["\']csrf_token["\'][^>]*value=["\']([^"\']+)["\']/i', $html, $m)) {
        return $m[1];
    }
    return null;
}

function extract_math_question(string $html): ?array {
    if (preg_match('/<div\s+class=["\']captcha-q["\'][^>]*>(.*?)<\/div>/is', $html, $m)) {
        $text = strip_tags($m[1]);
    } else {
        $text = strip_tags($html);
    }

    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = trim($text);

    $text = str_replace(['−', '–', '—', '‐', '‑', '‒', '&minus;'], '-', $text);
    $text = str_replace(['×', '&times;'], '*', $text);
    $text = str_replace(['÷', '&divide;'], '/', $text);

    if (preg_match('/what\s+is\s+(\d+)\s*([+\-*\/])\s*(\d+)\s*=\s*\?/i', $text, $m)) {
        return ['q1' => (int)$m[1], 'op' => $m[2], 'q2' => (int)$m[3]];
    }
    if (preg_match('/(\d+)\s*([+\-*\/])\s*(\d+)\s*=\s*\?/i', $text, $m)) {
        return ['q1' => (int)$m[1], 'op' => $m[2], 'q2' => (int)$m[3]];
    }
    if (preg_match('/(\d+)\s*([+\-*\/])\s*(\d+)\s*=/i', $text, $m)) {
        return ['q1' => (int)$m[1], 'op' => $m[2], 'q2' => (int)$m[3]];
    }
    return null;
}

function solve_math(array $math): int {
    $n1 = $math['q1'];
    $n2 = $math['q2'];
    switch ($math['op']) {
        case '+': return $n1 + $n2;
        case '-': return $n1 - $n2;
        case '*': return $n1 * $n2;
        case '/': return $n2 != 0 ? (int)($n1 / $n2) : 0;
        default:  return 0;
    }
}

function submit_claim($url, $cookie_file, $email, $csrf, $ans, $ua) {
    $postData = http_build_query([
        'action'      => 'claim',
        'csrf_token'  => $csrf,
        'website'     => '',
        'email'       => $email,
        'math_answer' => $ans,
    ]);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $postData,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_COOKIEJAR      => $cookie_file,
        CURLOPT_COOKIEFILE     => $cookie_file,
        CURLOPT_USERAGENT      => $ua,
        CURLOPT_HTTPHEADER     => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language: en-US,en;q=0.9',
            'Content-Type: application/x-www-form-urlencoded',
            'Origin: ' . rtrim($url, '/'),
            'Referer: ' . $url,
            'Cache-Control: no-cache',
            'Pragma: no-cache',
        ],
    ]);

    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    return [
        'body'  => $body ?: '',
        'code'  => $code,
        'error' => $err
    ];
}

function is_success_response(string $body): bool {
    $lower = strtolower($body);

    if (
        strpos($lower, 'alert-success') !== false ||
        strpos($lower, 'success! 1000 satoshi') !== false ||
        strpos($lower, 'sent to your faucetpay wallet') !== false ||
        strpos($lower, 'payout #') !== false
    ) {
        return true;
    }

    if (
        strpos($lower, 'alert-error') !== false ||
        strpos($lower, 'alert-banned') !== false ||
        strpos($lower, 'invalid') !== false ||
        strpos($lower, 'wrong answer') !== false ||
        strpos($lower, 'bot detected') !== false ||
        strpos($lower, 'vpn') !== false ||
        strpos($lower, 'proxy') !== false
    ) {
        return false;
    }

    return false;
}

// ======================= MAIN LOOP =======================
hacker_intro();
banner();

$config = [];
if (file_exists($CONFIG_FILE)) {
    $config = json_decode(file_get_contents($CONFIG_FILE), true) ?: [];
}

if (empty($config['email'])) {
    echo GREEN . "Masukkan Email FaucetPay: " . RESET;
    $config['email'] = trim(fgets(STDIN));
    $config['base_url'] = 'https://tronblow.site';
    file_put_contents($CONFIG_FILE, json_encode($config, JSON_PRETTY_PRINT));
}

echo WHITE . " Account : " . L_ORANGE . $config['email'] . RESET . "\n\n";

while (true) {
    $res = fetch_page($config['base_url'], $COOKIE_FILE, $UA);
    
    $csrf = extract_csrf_token($res['html']);
    $math = extract_math_question($res['html']);
    $ans  = $math ? solve_math($math) : 0;

    $log_time = WHITE . "[" . date("H:i:s") . "] ";

    if ($math) {
        typewrite($log_time . CYAN . "[Captcha] {$math['q1']} {$math['op']} {$math['q2']} = $ans" . RESET, 8000);
    }

    if ($csrf && $math !== null) {
        $result = submit_claim(
            $config['base_url'],
            $COOKIE_FILE,
            $config['email'],
            $csrf,
            $ans,
            $UA
        );

        if (!empty($result['error'])) {
            typewrite($log_time . RED . "❌ CURL Error: " . $result['error'] . RESET, 12000);
        } elseif (is_success_response($result['body'])) {
            typewrite($log_time . ORANGE . "✅ Success! Good Job Bro" . RESET, 12000);
            typewrite(GREEN . "✓ Reward 1000 satoshi sent to your FaucetPay" . RESET, 10000);
        } else {
            file_put_contents($LAST_RESPONSE, $result['body']);
            typewrite($log_time . RED . "❌ Failed / Cooldown / Rejected" . RESET, 12000);
            typewrite(WHITE . "   → Response disimpan di last_response.html (HTTP {$result['code']})" . RESET, 8000);
        }
    } else {
        typewrite($log_time . RED . "❌ Gagal extract CSRF/Captcha" . RESET, 12000);
        if (!empty($res['html'])) {
            file_put_contents($LAST_RESPONSE, $res['html']);
        }
    }

    timer(65, "Next claim");
    typewrite(ORANGE . "----------------------------------------------" . RESET, 8000);
}
