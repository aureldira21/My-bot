from fake_useragent import UserAgent

def main():
    ua = UserAgent()

    print("=== Fake User-Agent Generator ===")

    try:
        jumlah = int(input("Masukkan jumlah User-Agent: "))

        if jumlah <= 0:
            print("Jumlah harus lebih dari 0.")
            return

        print(f"\nMenghasilkan {jumlah} User-Agent...\n")

        for i in range(1, jumlah + 1):
            print(f"{i}. {ua.random}")

    except ValueError:
        print("Input harus berupa angka.")

if __name__ == "__main__":
    main()
