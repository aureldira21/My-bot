<?php

error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
$configFile = "config.json";

const hitam  = "\033[0;30m";
const merah  = "\033[0;31m";
const hijau  = "\033[0;32m";
const kuning = "\033[0;33m";
const biru   = "\033[0;34m";
const cyan   = "\033[0;36m";
const putih  = "\033[0;37m";
const reset  = "\033[0m";

const api_url       = "https://faucetmini.app/api.php";
const solver_in     = "https://api.waryono.my.id/in.php";
const solver_out    = "https://api.waryono.my.id/res.php";
const SITEKEY       = "0x4AAAAAABuBae9KLy3ELiTP";
const SOLVE_DOMAIN  = "https://faucetmini.app";
const GAMES         = ["spin", "balloon", "claw", "flip", "neon", "portal", "rocket", "tap"];
const ASSET         = "USDT";

function clear() {
    (PHP_OS == "Linux") ? system('clear') : pclose(popen('cls', 'w'));
}

function timer($seconds, $prefix = "[!] please wait") {
    $wait_time = (int)$seconds;
    if ($wait_time < 1) return;
    $frames = ['⣾', '⣽', '⣻', '⢿', '⡿', '⣟', '⣯', '⣷'];
    $frame_count = count($frames);
    $current_frame = 0;
    $frame_delay = 0.1;
    while ($wait_time > 0) {
        $start_time = microtime(true);
        while ((microtime(true) - $start_time) < 1) {
            $hours = floor($wait_time / 3600);
            $minutes = floor(($wait_time % 3600) / 60);
            $seconds_left = $wait_time % 60;
            $time_formatted = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds_left);
            $spinner = $frames[$current_frame];
            echo putih . $prefix . hijau . " $time_formatted " . putih . $spinner . "\r";
            usleep($frame_delay * 1000000);
            $current_frame = ($current_frame + 1) % $frame_count;
            if ((microtime(true) - $start_time) >= 1) break;
        }
        $wait_time--;
    }
    echo "\r                                     \r";
}

function getConfig($configFile) {
    if (!file_exists($configFile)) {
        echo putih . "API Key (turnstile solver) : " . kuning;
        $apikey = trim(fgets(STDIN));
        echo putih . "initData (TG WebView) : " . kuning;
        $initData = trim(fgets(STDIN));
        echo putih . "coupon_code (kosongkan jika tidak ada) : " . kuning;
        $coupon = trim(fgets(STDIN));
        file_put_contents($configFile, json_encode([
            "apikey" => $apikey, "initData" => $initData, "coupon_code" => $coupon
        ], JSON_PRETTY_PRINT));
        echo hijau . "Konfigurasi disimpan ke $configFile\n\n" . reset;
        sleep(2);
        return ["apikey" => $apikey, "initData" => $initData, "coupon_code" => $coupon];
    }
    return json_decode(file_get_contents($configFile), true);
}

function wkwk($url, $payload = null, $headers = [], $method = "POST") {
    while (true) {
        $ch = curl_init();
        $final = [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_CONNECTTIMEOUT => 30,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_COOKIEFILE     => 'cookies.txt',
            CURLOPT_COOKIEJAR      => 'cookies.txt'
        ];
        if ($method === "POST") {
            $final[CURLOPT_POST] = true;
            $final[CURLOPT_POSTFIELDS] = json_encode($payload);
        }
        curl_setopt_array($ch, $final);
        $response = curl_exec($ch);
        curl_close($ch);
        if ($response) return $response;
        echo putih . "\nwiwok detok, retry...\n";
        sleep(2);
    }
}

function api_call($action, $extra = []) {
    global $initData;
    $payload = array_merge([
        "action"   => $action,
        "initData" => $initData,
        "clientInfo" => [
            "user_agent" => "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 Chrome/151.0 Mobile Safari/537.36",
            "platform"   => "android",
            "timezone"   => "Asia/Jakarta"
        ]
    ], $extra);
    $res = wkwk(api_url, $payload, $GLOBALS['HEADERS']);
    $json = json_decode($res, true);
    if (!is_array($json)) return ["status" => "error", "message" => substr($res, 0, 300)];
    return $json;
}

$HEADERS = [
    'content-type: application/json',
    'user-agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.7922.199 Mobile Safari/537.36 Telegram-Android/12.9.1',
    'accept: application/json, text/plain, */*',
    'origin: https://faucetmini.app',
    'referer: https://faucetmini.app/',
    'accept-language: en,id-ID;q=0.9,id;q=0.8'
];

function solve_captcha($apikey, $action) {
    while (true) {
        $body = [
            "apikey"  => $apikey,
            "methods" => "turnstile",
            "domain"  => SOLVE_DOMAIN,
            "sitekey" => SITEKEY,
            "action"  => $action,
            "cdata"   => "",
            "json"    => 1
        ];
        $request = wkwk(solver_in, $body, ["Content-Type: application/json"]);
        foreach (["ERROR_WRONG_METHOD", "ERROR_KEY_DOES_NOT_EXIST", "ERROR_NO_SUCH_METHOD", "ERROR_WRONG_USER_KEY", "ERROR_ZERO_BALANCE", "ERROR_BAD_PARAMETERS", "ERROR_UNKNOWN"] as $e) {
            if (strpos($request, $e) !== false) {
                echo putih . "Error: " . merah . $e . "\n";
                exit;
            }
        }
        if (strpos($request, "ERROR_TOO_MANY_REQUESTS") !== false) { sleep(2); continue; }
        $id = (json_decode($request, true))["request"];

        while (true) {
            timer(5, "  captcha...");
            $result = wkwk(solver_out . "?apikey=" . $apikey . "&action=get&id=" . $id . "&json=1", null, [], "GET");
            if (strpos($result, "CAPCHA_NOT_READY") !== false) continue;
            $json = json_decode($result, true);
            $tok = is_array($json) ? ($json["request"] ?? "") : "";
            if (is_string($tok) && strlen($tok) > 50 && strpos($tok, ".") !== false) {
                echo putih . "[CAPTCHA] " . hijau . "OK\n";
                return $tok;
            }
            echo putih . "[CAPTCHA] " . kuning . "respon aneh: " . substr(is_array($json) ? json_encode($json) : $result, 0, 120) . "\n";
            sleep(3);
            continue;
        }
    }
}

function fetch_user() {
    $r = api_call("get_user_data");
    return ($r['status'] ?? '') == 'success' ? ($r['data'] ?? $r) : null;
}

function fetch_profile() {
    $r = api_call("get_user_profile");
    return ($r['status'] ?? '') == 'success' ? ($r['data'] ?? $r) : null;
}

function fmt_num($n) {
    return rtrim(rtrim(number_format((float)$n, 8, '.', ''), '0'), '.');
}

function asset_of($d) {
    $sym = strtoupper(trim($d['asset_symbol'] ?? $d['symbol'] ?? ASSET));
    return preg_match('/^[A-Z0-9]{2,10}$/', $sym) ? $sym : ASSET;
}

function cooldown_wait_of($j, $default = 60) {
    foreach (['global_game_cooldown_remaining', 'faucet_global_cooldown_remaining', 'cooldown_remaining', 'post_claim_start_cooldown_remaining'] as $k) {
        if (isset($j[$k]) && intval($j[$k]) > 0) return intval($j[$k]);
    }
    foreach (['global_game_cooldown_seconds', 'faucet_global_cooldown_seconds'] as $k) {
        if (isset($j[$k]) && intval($j[$k]) > 0) return intval($j[$k]);
    }
    return $default;
}

function daily_bonus() {
    $st = api_call("get_daily_bonus_status");
    if (($st['status'] ?? '') != 'success') {
        echo putih . "[DAILY] " . kuning . ($st['message'] ?? 'gagal get status') . "\n";
        return;
    }
    $d = $st['data'] ?? $st;
    if (empty($d['can_claim'])) {
        echo putih . "[DAILY] " . kuning . "belum waktunya (day " . ($d['current_day'] ?? $d['day'] ?? '?') . ")\n";
        return;
    }
    echo putih . "[DAILY] " . kuning . "claim day " . ($d['current_day'] ?? $d['day'] ?? '?') . "...\n";
    $r = api_call("claim_daily_bonus");
    if (($r['status'] ?? '') == 'success') {
        $rd = $r['data'] ?? $r;
        echo putih . "[DAILY] " . hijau . "OK +" . fmt_num($rd['reward_amount'] ?? $rd['reward'] ?? '?') . " " . strtoupper($rd['reward_coin'] ?? $rd['coin'] ?? ASSET) . "\n";
    } else {
        echo putih . "[DAILY] " . merah . ($r['message'] ?? 'gagal claim') . "\n";
    }
}

function referral_claim() {
    $r = api_call("claim_referral_earnings");
    if (($r['status'] ?? '') == 'success') {
        echo putih . "[REF] " . hijau . ($r['message'] ?? 'OK') . "\n";
    } else {
        echo putih . "[REF] " . kuning . ($r['message'] ?? 'gagal') . "\n";
    }
}

function coupon_redeem($code = '') {
    if ($code === '') {
        echo putih . "Kode coupon: " . kuning;
        $code = trim(fgets(STDIN));
        if ($code === '') { echo putih . "batal.\n"; return; }
    }
    echo putih . "[COUPON] " . kuning . "redeem " . $code . "...\n";
    $r = api_call("redeem_daily_coupon", ["coupon_code" => $code]);
    if (($r['status'] ?? '') == 'success') {
        echo putih . "[COUPON] " . hijau . ($r['message'] ?? 'OK') . "\n";
    } else {
        echo putih . "[COUPON] " . merah . ($r['message'] ?? 'gagal') . "\n";
    }
}

function claim_all_game() {
    global $apikey;
    $ready_at = [];
    $mode_idx = -1;
    $notified = [];

    echo putih . "[faucetmini " . kuning . "claim all game" . putih . "]\n";
    echo putih . "------------------------------------------\n";

    while (true) {
        $d = fetch_user();
        if (!$d) {
            echo putih . "[DATA] " . merah . "gagal get_user_data\n";
            timer(60, "  retry...");
            continue;
        }
        $gs = (isset($d['game_stats']) && is_array($d['game_stats'])) ? $d['game_stats'] : [];

        $global_left = cooldown_wait_of($d, 0);
        if ($global_left > 0) {
            timer($global_left, "  cooldown...");
            continue;
        }

        $now = time();
        $shortest = 999999;
        $rate = false;
        $tried = false;
        $picked = null;

        for ($k = 0; $k < count(GAMES); $k++) {
            $mode_idx = ($mode_idx + 1) % count(GAMES);
            $m = GAMES[$mode_idx];
            if (isset($ready_at[$m]) && $ready_at[$m] > $now) {
                $shortest = min($shortest, $ready_at[$m] - $now);
                continue;
            }
            $s = $gs[$m] ?? [];
            if (!empty($s['last_claim_timestamp_unix']) && intval($s['spins_today'] ?? 0) > 0) {
                $cd = intval($s['cooldown_seconds'] ?? $d['global_game_cooldown_seconds'] ?? 60);
                $ends = intval($s['last_claim_timestamp_unix']) + $cd;
                if ($ends > $now) {
                    $ready_at[$m] = $ends;
                    $shortest = min($shortest, $ends - $now);
                    continue;
                }
            }
            $picked = $m;
            break;
        }
        if (!$picked) {
            $wait = ($shortest < 999999) ? $shortest : 30;
            if ($wait < 1) $wait = 5;
            timer($wait, "  waiting...");
            continue;
        }

        $tried = true;
        $spin = api_call("get_faucet_spin_reward", ["gameType" => $picked]);
        if (($spin['status'] ?? '') != 'success') {
            $msg = $spin['message'] ?? '';
            if ($msg === '') $msg = substr(json_encode($spin), 0, 200);
            if (stripos($msg, 'too many') !== false || stripos($msg, 'rate') !== false) {
                $rate = true;
                break;
            }
            $rem = intval($spin['cooldown_remaining'] ?? 0);
            if ($rem > 0) {
                $ready_at[$picked] = $now + $rem;
                $shortest = min($shortest, $rem);
                continue;
            }
            if (stripos($msg, 'limit') !== false || stripos($msg, 'exhaust') !== false || stripos($msg, 'daily') !== false || stripos($msg, 'cap') !== false) {
                if (empty($notified[$picked])) {
                    echo putih . "[" . cyan . $picked . putih . "] " . kuning . "limit tercapai\n";
                    $notified[$picked] = true;
                }
                $ready_at[$picked] = $now + 3600;
                continue;
            }
            echo putih . "[" . cyan . $picked . putih . "] " . merah . $msg . "\n";
            sleep(3);
            continue;
        }

        $tok = solve_captcha($apikey, "faucet_claim");
        $cf = api_call("claim_faucet", ["gameType" => $picked, "captchaToken" => $tok, "requireDouble" => false]);
        if (($cf['status'] ?? '') != 'success') {
            $msg = $cf['message'] ?? '';
            if ($msg === '') $msg = substr(json_encode($cf), 0, 200);
            if (stripos($msg, 'too many') !== false || stripos($msg, 'rate') !== false) {
                $rate = true;
                break;
            }
            $rem = intval($cf['cooldown_remaining'] ?? 0);
            if ($rem > 0) {
                $ready_at[$picked] = $now + $rem;
                $shortest = min($shortest, $rem);
            }
            echo putih . "[" . cyan . $picked . putih . "] " . merah . $msg . "\n";
            sleep(5);
            continue;
        }

        $data = $cf['data'] ?? $cf;
        $amt = $data['credited_amount'] ?? $data['claimed_amount'] ?? $data['base_reward'] ?? $data['reward_amount'] ?? '?';
        $mult = (!empty($data['double_applied'])) ? floatval($data['multiplier'] ?? $data['double_reward_multiplier'] ?? 2) : 1;
        $bal = $data['balance'] ?? $d['balance'] ?? '?';
        echo putih . "[" . cyan . $picked . putih . "] +" . hijau . fmt_num($amt) . " " . ASSET . ($mult > 1 ? putih . " x" . hijau . $mult : "") . " - balance " . biru . fmt_num($bal) . "\n";

        $gcd = cooldown_wait_of($cf, 60);
        timer($gcd, "  next claim...");
    }
}

function do_withdraw() {
    global $apikey;


    $prof = fetch_profile();
    if (!$prof) {
        echo putih . "[WD] " . merah . "gagal get_user_profile\n";
        return;
    }
    $bal  = $prof['balance'] ?? 0;
    $asset = asset_of($prof);
    $email = $prof['email'] ?? '';
    $tgid  = $prof['tg_id'] ?? '';
    $ton   = $prof['ton_wallet_address'] ?? '';

    $DEFAULTS = ['faucetpay' => 0.0025, 'cwallet' => 0.005, 'xrocket' => 0.01, 'tonconnect' => 0.05];
    $minimums = $prof['withdraw_minimums'] ?? [];
    $dest = ['faucetpay' => $email, 'cwallet' => $email, 'xrocket' => $tgid, 'tonconnect' => $ton];
    $dest_label = ['faucetpay' => 'FaucetPay email', 'cwallet' => 'Cwallet email', 'xrocket' => 'Telegram ID', 'tonconnect' => 'TON wallet'];

    echo putih . "[faucetmini " . kuning . "withdraw" . putih . "]\n";
    echo putih . "------------------------------------------\n\n";
    echo putih . "Balance : " . biru . fmt_num($bal) . " " . $asset . "\n";
    echo putih . "Email   : " . cyan . ($email === '' ? '(belum diset)' : $email) . "\n";
    echo putih . "TON     : " . cyan . ($ton === '' ? '(belum diset)' : $ton) . "\n\n";

    $methods = ['faucetpay', 'cwallet', 'xrocket', 'tonconnect'];
    foreach ($methods as $i => $mt) {
        $min = is_numeric($minimums[$mt] ?? null) ? floatval($minimums[$mt]) : $DEFAULTS[$mt];
        $is_ready = ($dest[$mt] !== '') ? "" : " (destinasi belum diset)";
        echo putih . "  " . ($i + 1) . ". " . str_pad($mt, 10) . " [min " . fmt_num($min) . " " . $asset . "]" . kuning . $is_ready . "\n";
    }
    echo putih . "  0. Batal\n";
    echo putih . "pilih: " . kuning;
    $opt = trim(fgets(STDIN));
    if ($opt < 1 || $opt > 4) { echo putih . "batal.\n"; return; }
    $method = $methods[$opt - 1];

    if ($dest[$method] === '') {
        echo "\n" . putih . $dest_label[$method] . " belum diset.\n";
        if ($method === 'tonconnect') {
            echo putih . "Alamat TON : " . kuning;
            $addr = trim(fgets(STDIN));
            if ($addr === '') { echo putih . "batal.\n"; return; }
            $up = api_call("update_ton_wallet", ["walletAddress" => $addr]);
            $dest[$method] = $addr;
        } elseif ($method === 'xrocket') {
            echo putih . "TG ID (dari @userinfobot) : " . kuning;
            $addr = trim(fgets(STDIN));
            if ($addr === '') { echo putih . "batal.\n"; return; }
            $dest[$method] = $addr;
        } else {
            echo putih . "Email " . $dest_label[$method] . " : " . kuning;
            $addr = trim(fgets(STDIN));
            if ($addr === '') { echo putih . "batal.\n"; return; }
            $up = api_call("update_user_email", ["email" => $addr]);
            $dest[$method] = $addr;
        }
        if (($up['status'] ?? '') != 'success') {
            echo putih . "[SET] " . merah . ($up['message'] ?? 'gagal update') . "\n";
            return;
        }
        echo putih . "[SET] " . hijau . "OK\n";
    }

    $min = is_numeric($minimums[$method] ?? null) ? floatval($minimums[$method]) : $DEFAULTS[$method];
    if (floatval($bal) < $min) {
        echo putih . "[!] Saldo kurang: " . fmt_num($bal) . " < min " . fmt_num($min) . "\n";
        return;
    }

    echo "\n";
    echo putih . "Konfirmasi withdraw saldo penuh:\n";
    echo putih . "  method  : " . cyan . $method . "\n";
    echo putih . "  tujuan  : " . cyan . $dest[$method] . "\n";
    echo putih . "  jumlah  : " . cyan . fmt_num($bal) . " " . $asset . "\n";
    echo putih . "Lanjut? (y/N): " . kuning;
    $ok = strtolower(trim(fgets(STDIN)));
    if ($ok !== 'y' && $ok !== 'yes') { echo putih . "batal.\n"; return; }

    echo putih . "[CAPTCHA] " . kuning . "solving turnstile...\n";
    $tok = solve_captcha($apikey, "withdraw_funds");
    echo putih . "[WD] " . kuning . "kirim via " . $method . "...\n";
    $r = api_call("withdraw_funds", ["method" => $method, "currency" => $asset, "captchaToken" => $tok]);
    if (($r['status'] ?? '') == 'success' || ($r['status'] ?? '') == 'pending') {
        echo putih . "[WD] " . hijau . ($r['message'] ?? 'OK') . "\n";
    } else {
        echo putih . "[WD] " . merah . ($r['message'] ?? json_encode($r)) . "\n";
    }
}

clear();
$config   = getConfig($configFile);
$apikey   = $config['apikey'];
$initData = $config['initData'];
$coupon_code = trim($config['coupon_code'] ?? '');

while (true) {
    clear();
    echo putih . "FaucetMini Bot\n";

    $d = fetch_user();
    if ($d) {
        echo putih . "balance: " . biru . fmt_num($d['balance'] ?? 0) . " " . asset_of($d) . "\n";
    } else {
        echo putih . "balance: " . merah . "gagal fetch\n";
    }

    echo "\n";
    echo putih . "  1. " . cyan . "Claim All Game" . putih . " (rotasi 8 game)\n";
    echo putih . "  2. " . cyan . "Daily Bonus\n";
    echo putih . "  3. " . cyan . "Claim Referral Earnings\n";
    echo putih . "  4. " . cyan . "Redeem Daily Coupon\n";
    echo putih . "  5. " . cyan . "Withdraw\n";
    echo putih . "  0. " . merah . "Exit\n";
    echo putih . "pilih: " . kuning;
    $opt = trim(fgets(STDIN));

    if ($opt == '1') {
        claim_all_game();
        echo "\n" . putih . "enter untuk kembali...";
        fgets(STDIN);
    } elseif ($opt == '2') {
        daily_bonus();
        echo "\n" . putih . "enter untuk kembali...";
        fgets(STDIN);
    } elseif ($opt == '3') {
        referral_claim();
        echo "\n" . putih . "enter untuk kembali...";
        fgets(STDIN);
    } elseif ($opt == '4') {
        coupon_redeem($coupon_code);
        echo "\n" . putih . "enter untuk kembali...";
        fgets(STDIN);
    } elseif ($opt == '5') {
        do_withdraw();
        echo "\n" . putih . "enter untuk kembali...";
        fgets(STDIN);
    } elseif ($opt == '0') {
        exit;
    }
}
