<?php
/**
 * CLAIMX AUTO CLAIM BOT v8.0
 * Structure & Faucet Logic: Script 1 (ad-verify API)
 * Display, Banner & Tier Detector: Script 2
 */

error_reporting(0);
date_default_timezone_set('Asia/Jakarta');

// ============================================================
//  COLOR CONSTANTS
// ============================================================
define('RESET', "\033[0m");
define('BOLD', "\033[1m");
define('RED', "\033[31m");
define('GREEN', "\033[32m");
define('YELLOW', "\033[33m");
define('BLUE', "\033[34m");
define('MAGENTA', "\033[35m");
define('CYAN', "\033[36m");
define('WHITE', "\033[37m");
define('GRAY', "\033[90m");
define('B_RED', "\033[1;31m");
define('B_GREEN', "\033[1;32m");
define('B_YELLOW', "\033[1;33m");
define('B_BLUE', "\033[1;34m");
define('B_CYAN', "\033[1;36m");
define('B_WHITE', "\033[1;37m");
define('B_MAGENTA', "\033[1;35m");
define('GOLD', "\033[38;5;220m"); // Warna Emas

// ============================================================
//  CONFIG
// ============================================================
const HOST             = 'https://claimx.online';
const CONFIG_FILE      = 'claimx_config.json';
const COOKIE_FILE      = 'claimx_cookie.txt';
const DAILY_FILE       = 'claimx_daily.txt';

// ============================================================
//  FUNGSI BANTU & ANIMASI KETIK (LOG)
// ============================================================
function clearScreen() { 
    (PHP_OS == "Linux") ? system('clear') : pclose(popen('cls', 'w')); 
}

function printType($text, $speed = 30000) { 
    $length = mb_strlen($text);
    for ($i = 0; $i < $length; $i++) {
        echo mb_substr($text, $i, 1);
        usleep($speed);
    }
}

function logMessage($prefixColor, $prefixText, $message, $messageColor = WHITE) {
    echo $prefixColor . $prefixText . " " . $messageColor;
    printType($message, 30000);
    echo RESET . "\n";
}

function printBanner($tierName = "Checking...", $maxLimit = 100) {
    clearScreen();
    $termwidth = 44;

    $b1 = "========================================";
    $b2 = "         ClaimX Auto Claim Bot          ";
    $b3 = "      Icon Captcha & Ad-Verify API      ";
    $b4 = "        Credit to ScriptyXsouu          ";
    $b5 = "  https://t.me/+f3QBLkR5D8k4YzNl";

    // Garis atas banner (Emas)
    echo GOLD . str_pad($b1, $termwidth, " ", STR_PAD_BOTH) . "\n" . RESET;
    echo GOLD . BOLD . YELLOW . str_pad($b2, $termwidth, " ", STR_PAD_BOTH) . RESET . "\n";
    echo GOLD . BOLD . YELLOW . str_pad($b3, $termwidth, " ", STR_PAD_BOTH) . RESET . "\n";
    echo GOLD . BOLD . GREEN  . str_pad($b4, $termwidth, " ", STR_PAD_BOTH) . RESET . "\n";
    echo CYAN . BOLD . str_pad($b5, $termwidth, " ", STR_PAD_BOTH) . RESET . "\n";
    // Garis bawah banner (Emas)
    echo GOLD . str_pad($b1, $termwidth, " ", STR_PAD_BOTH) . "\n" . RESET;
    echo CYAN . "  Website : " . WHITE . HOST . "\n";
    echo CYAN . "  Tier    : " . GOLD . $tierName . "\n";
    echo CYAN . "  Limit   : " . WHITE . $maxLimit . " claim/hari\n";
    echo CYAN . "  Jeda    : " . WHITE . "14-19 detik (Human-like)\n";
    echo CYAN . "  API Key : " . WHITE . "No API Key needed\n";
    // Penutup banner informasi (Emas)
    echo GOLD . "  ========================================\n\n" . RESET;
}

// ============================================================
//  TIMER DENGAN ANIMASI LAMPU KNIGHT RIDER
// ============================================================
function timer($seconds, $prefix = "  ⏳ Waiting: ") {
    $wait_time = (int)$seconds;
    if ($wait_time <= 0) return;

    while ($wait_time > 0) {
        $hours = floor($wait_time / 3600);
        $minutes = floor(($wait_time % 3600) / 60);
        $seconds_left = $wait_time % 60;
        $time_formatted = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds_left);
        
        $bar_length = 10;
        $positions = array_merge(range(0, $bar_length - 1), range($bar_length - 2, 1));
        foreach ($positions as $pos) {
            $bar = "";
            for ($i = 0; $i < $bar_length; $i++) {
                if ($i == $pos) {
                    $bar .= RED . "█" . RESET;
                } else {
                    $bar .= GRAY . "░" . RESET;
                }
            }
            echo "\r" . B_YELLOW . $prefix . B_WHITE . $time_formatted . " [" . $bar . "] " . RESET;
            usleep(100000);
        }
        $wait_time--;
    }
    echo "\r" . str_repeat(" ", 65) . "\r";
}

function humanDelayTimer($seconds) {
    $wait_time = (int)$seconds;
    while ($wait_time > 0) {
        $time_formatted = "{$wait_time}s  ";
        
        $bar_length = 10;
        $positions = array_merge(range(0, $bar_length - 1), range($bar_length - 2, 1));
        foreach ($positions as $pos) {
            $bar = "";
            for ($i = 0; $i < $bar_length; $i++) {
                if ($i == $pos) {
                    $bar .= RED . "█" . RESET;
                } else {
                    $bar .= GRAY . "░" . RESET;
                }
            }
            echo "\r" . WHITE . "  ⏳ Next claim: " . B_WHITE . $time_formatted . " [" . $bar . "] " . RESET;
            usleep(100000);
        }
        $wait_time--;
    }
    echo "\r" . str_repeat(" ", 65) . "\r";
    echo YELLOW . "  ----------------------------------------\n" . RESET;
}

// ============================================================
//  HTTP (SIMPLE — OLD STYLE + NO FOLLOW)
// ============================================================
function req($url, $method = 'GET', $post = null, $extra = []) {
    $ch = curl_init();
    $headers = array_merge([
        'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language: id-ID,id;q=0.9,en;q=0.8',
        'Accept-Encoding: gzip, deflate, br',
        'Connection: keep-alive',
        'Upgrade-Insecure-Requests: 1',
    ], $extra);
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_COOKIEFILE => COOKIE_FILE,
        CURLOPT_COOKIEJAR  => COOKIE_FILE,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_ENCODING => '',
    ]);
    if (strtoupper($method) === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    $r = curl_exec($ch);
    $err = curl_errno($ch);
    curl_close($ch);
    return $err ? false : $r;
}

function reqNoFollow($url, $post = null, $extra = []) {
    $ch = curl_init();
    $headers = array_merge([
        'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
        'Accept: */*',
        'Accept-Language: id-ID,id;q=0.9,en;q=0.8',
        'Accept-Encoding: gzip, deflate, br',
        'Connection: keep-alive',
        'X-Requested-With: XMLHttpRequest',
    ], $extra);
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_COOKIEFILE => COOKIE_FILE,
        CURLOPT_COOKIEJAR  => COOKIE_FILE,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_ENCODING => '',
    ]);
    if ($post !== null) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    $r = curl_exec($ch);
    $err = curl_errno($ch);
    curl_close($ch);
    return $err ? false : $r;
}

// ============================================================
//  PARSERS & DYNAMIC DETECTOR
// ============================================================
function parseCSRF($html) {
    if (preg_match('/<input[^>]*name=["\']csrf_token["\'][^>]*value=["\']([^"\']+)["\']/i', $html, $m)) return $m[1];
    if (preg_match('/csrf_token\s*[:=]\s*["\']([^"\']+)["\']/i', $html, $m)) return $m[1];
    return null;
}

function parseIconCaptcha($html) {
    $target = null;
    if (preg_match('/<div[^>]*class="[^"]*text-warning[^"]*"[^>]*>.*?<i[^>]*class="([^"]+)"[^>]*><\/i>/si', $html, $m)) {
        $target = $m[1];
    } elseif (preg_match('/<div[^>]*class="[^"]*bg-dark[^"]*border-warning[^"]*"[^>]*>.*?<i[^>]*class="([^"]+)"[^>]*><\/i>/si', $html, $m)) {
        $target = $m[1];
    }
    $choices = [];
    if (preg_match_all('/<button[^>]*data-key="([^"]+)"[^>]*>.*?<i[^>]*class="([^"]+)"[^>]*><\/i>.*?<\/button>/si', $html, $ms, PREG_SET_ORDER)) {
        foreach ($ms as $m) $choices[] = ['key'=>$m[1], 'icon'=>$m[2]];
    }
    return [$target, $choices];
}

function matchIcon($target, $choices) {
    if (!$target || empty($choices)) return null;
    foreach ($choices as $c) {
        $tp = explode(' ', $target);
        $cp = explode(' ', $c['icon']);
        foreach ($tp as $a) foreach ($cp as $b) {
            if (strcasecmp($a, $b) === 0 && strpos($a, 'bi-') !== false) return $c['key'];
        }
        if (strcasecmp($target, $c['icon']) === 0) return $c['key'];
    }
    return null;
}

// Fungsi Otomatis Deteksi Tier & Limit Harian dari Dashboard
function getAccountMembershipInfo() {
    $html = req(HOST . '/dashboard');
    if (!$html) return ['tier' => 'Free', 'limit' => 100];

    $tier = 'Free';
    $limit = 100;

    if (stripos($html, 'Bronze') !== false) {
        $tier = 'Bronze';
        $limit = 300;
    } elseif (stripos($html, 'Silver') !== false) {
        $tier = 'Silver';
        $limit = 500; 
    } elseif (stripos($html, 'Gold') !== false) {
        $tier = 'Gold';
        $limit = 1500;
    }

    if (preg_match('/Daily Claims.*?([0-9]+)/si', $html, $m)) {
        $parsedLimit = (int)$m[1];
        if ($parsedLimit > 0) {
            $limit = $parsedLimit;
        }
    }

    return ['tier' => $tier, 'limit' => $limit];
}

// ============================================================
//  DAILY COUNTER
// ============================================================
function getDailyCount() {
    if (file_exists(DAILY_FILE)) {
        $d = json_decode(file_get_contents(DAILY_FILE), true);
        if (($d['date'] ?? '') === date('Y-m-d')) return (int)$d['count'];
    }
    return 0;
}
function updateDailyCount($c) {
    file_put_contents(DAILY_FILE, json_encode(['date'=>date('Y-m-d'), 'count'=>$c]));
}
function resetDailyIfNeeded() {
    if (file_exists(DAILY_FILE)) {
        $d = json_decode(file_get_contents(DAILY_FILE), true);
        if (($d['date'] ?? '') !== date('Y-m-d')) { updateDailyCount(0); return true; }
    }
    return false;
}

// ============================================================
//  BALANCE / LIMIT
// ============================================================
function getBalance() {
    $html = req(HOST . '/dashboard');
    if (!$html) return '0.00000000';
    $pats = [
        '/Earnings Balance.*?<h3[^>]*class="[^"]*fs-4[^"]*"[^>]*>([0-9.]+)/si',
        '/balance[^>]*>([0-9.]+)/si',
        '/text-success[^>]*>([0-9.]+)/si',
    ];
    foreach ($pats as $p) if (preg_match($p, $html, $m)) return $m[1];
    return '0.00000000';
}

function checkDailyLimit($html) {
    return strpos($html, 'Daily Limit Reached') !== false
        || strpos($html, 'You have completed all') !== false
        || strpos($html, 'Upgrade Membership') !== false;
}

function isLoginPage($html) {
    return strpos($html, 'Sign In') !== false
        && strpos($html, 'iconCaptchaSelected') !== false
        && strpos($html, 'id="faucetForm"') === false;
}

// ============================================================
//  LOGIN
// ============================================================
function doLogin($email, $password) {
    logMessage(WHITE, "  [LOGIN]", "Attempting login...", WHITE);

    if (file_exists(COOKIE_FILE)) @unlink(COOKIE_FILE);

    $html = false;
    for ($i = 1; $i <= 3; $i++) {
        $html = req(HOST . '/login');
        if ($html && strlen($html) > 500) break;
        logMessage(B_YELLOW, "  [RETRY $i/3]", "Fetch /login gagal, tunggu 5s...", YELLOW);
        sleep(5);
    }

    if (!$html || strlen($html) < 500) {
        logMessage(WHITE, "  [ERROR]", "Gagal fetch /login (setelah 3x)", RED);
        return false;
    }

    $csrf = parseCSRF($html);
    if (!$csrf) { logMessage(WHITE, "  [ERROR]", "CSRF login ga ketemu", RED); return false; }

    list($target, $choices) = parseIconCaptcha($html);
    if (!$target || empty($choices)) { logMessage(WHITE, "  [ERROR]", "Captcha login ga ketemu", RED); return false; }

    $key = matchIcon($target, $choices);
    if (!$key) { logMessage(WHITE, "  [ERROR]", "Ikon login ga match", RED); return false; }

    echo CYAN . "  [LOGIN] icon: {$target} → {$key}\n" . RESET;

    $post = http_build_query([
        'csrf_token' => $csrf,
        'email' => $email,
        'password' => $password,
        'icon_captcha_selected' => $key
    ]);
    $r = req(HOST . '/login', 'POST', $post, [
        'Content-Type: application/x-www-form-urlencoded',
        'Origin: ' . HOST,
        'Referer: ' . HOST . '/login',
    ]);
    if ($r === false) { logMessage(WHITE, "  [ERROR]", "POST login gagal", RED); return false; }

    if (strpos($r, 'Dashboard') !== false || strpos($r, 'Welcome back') !== false) {
        logMessage(B_GREEN, "  [SUCCESS]", "Login OK", GREEN);
        return true;
    }
    logMessage(WHITE, "  [ERROR]", "Login reject", RED);
    return false;
}

// ============================================================
//  AD-TOKEN
// ============================================================
function fetchAdToken($csrf) {
    $body = 'csrf_token=' . urlencode($csrf);
    $r = reqNoFollow(HOST . '/faucet/verify-ad', $body, [
        'Content-Type: application/x-www-form-urlencoded',
        'Origin: ' . HOST,
        'Referer: ' . HOST . '/faucet',
    ]);

    if ($r === false) return ['ok'=>false, 'raw'=>'curl failed'];

    $j = json_decode($r, true);
    if (is_array($j) && !empty($j['success']) && !empty($j['token'])) {
        return ['ok'=>true, 'token'=>$j['token'], 'raw'=>$r];
    }

    return ['ok'=>false, 'token'=>null, 'raw'=>$r];
}

// ============================================================
//  CLAIM
// ============================================================
function claimFaucet(&$info) {
    $html = req(HOST . '/faucet');
    if (!$html) return 'fetch_fail';

    if (isLoginPage($html)) return 'session_invalid';

    if (checkDailyLimit($html)) {
        logMessage(B_WHITE, "  [LIMIT]", "Limit harian terpenuhi! BESOK LAGI YA!", B_WHITE);
        return 'limit_reached';
    }

    if (strpos($html, 'id="faucetForm"') === false) {
        if (preg_match('/id="countdownClock"[^>]*data-seconds=["\']?(\d+)/i', $html, $m)) {
            $s = (int)$m[1];
            if ($s > 0) return ['cooldown' => $s];
        }
        return 'no_form';
    }

    $csrf = parseCSRF($html);
    if (!$csrf) return 'no_csrf';

    echo CYAN . "  [FAUCET] Processing...\n" . RESET;

    for ($i = 6; $i > 0; $i--) {
        echo "\r  " . CYAN . "[AD] Viewing sponsored ad: " . WHITE . "{$i}s" . RESET . "   ";
        sleep(1);
    }
    echo "\r" . str_repeat(' ', 50) . "\r";

    logMessage(CYAN, "  [AD]", "Requesting verify-ad token...", WHITE);
    $tokRes = fetchAdToken($csrf);

    if (!$tokRes['ok'] && stripos($tokRes['raw'], 'at least 5 seconds') !== false) {
        logMessage(B_YELLOW, "  [AD]", "Server minta 5s+, tunggu 4s lagi...", YELLOW);
        sleep(4);
        $tokRes = fetchAdToken($csrf);
    }

    if (!$tokRes['ok']) {
        logMessage(WHITE, "  [AD]", "token gagal | " . substr($tokRes['raw'], 0, 120), RED);
        return 'ad_token_fail';
    }

    $token = $tokRes['token'];
    echo CYAN . "  [AD] token: " . WHITE . substr($token, 0, 16) . "...\n" . RESET;

    $postArr = [
        'csrf_token' => $csrf,
        'ad_verification_token' => $token,
    ];

    if (strpos($html, 'id="iconCaptchaSelected"') !== false) {
        list($target, $choices) = parseIconCaptcha($html);
        if ($target && !empty($choices)) {
            $key = matchIcon($target, $choices);
            if ($key) {
                echo CYAN . "  [CAPTCHA] {$target} → {$key}\n" . RESET;
                $postArr['icon_captcha_selected'] = $key;
            } else {
                logMessage(B_YELLOW, "  [CAPTCHA]", "ikon ga match, skip round", YELLOW);
                return 'captcha_skip';
            }
        } else {
            logMessage(CYAN, "  [CAPTCHA]", "kosong di page, skip", WHITE);
        }
    } else {
        logMessage(CYAN, "  [CAPTCHA]", "kosong di page, skip", WHITE);
    }

    $r = req(HOST . '/faucet/claim', 'POST', http_build_query($postArr), [
        'Content-Type: application/x-www-form-urlencoded',
        'Origin: ' . HOST,
        'Referer: ' . HOST . '/faucet',
    ]);
    if ($r === false) return 'fetch_fail';

    if (isLoginPage($r)) return 'session_invalid';
    if (checkDailyLimit($r)) return 'limit_reached';

    $amount = null;
    if (preg_match('/Claim successful!\s*Received\s*\+?([0-9.]+)\s*USDT/i', $r, $m)) {
        $amount = $m[1];
    } elseif (preg_match('/alert-success[^>]*>([^<]*?Received[^<]*?)</i', $r, $m)) {
        if (preg_match('/([0-9.]+)/', $m[1], $n)) $amount = $n[1];
    }

    if ($amount) {
        logMessage(B_GREEN, "  [SUCCESS]", "+{$amount} USDT", GREEN);
        $info = ['amount' => $amount];
        return true;
    }

    if (preg_match('/alert-(?:danger|warning)[^>]*>([^<]+)</i', $r, $m)) {
        $err = trim($m[1]);
        logMessage(WHITE, "  [SERVER]", "{$err}", RED);

        if (stripos($err, 'adblock') !== false) return ['cooldown' => rand(30, 45)];
        if (stripos($err, 'wait') !== false || stripos($err, 'cooldown') !== false) {
            $cd = 30;
            if (preg_match('/(\d+)\s*second/i', $err, $s)) $cd = (int)$s[1];
            return ['cooldown' => $cd];
        }
        if (stripos($err, 'captcha') !== false || stripos($err, 'verification') !== false || stripos($err, 'token') !== false) {
            return 'captcha_skip';
        }
    }

    if (strlen($r) < 100) return 'fetch_fail';

    file_put_contents("claim_fail.html", $r);
    logMessage(WHITE, "  [ERROR]", "Claim unknown → claim_fail.html", RED);
    return 'unknown';
}

// ============================================================
//  FARMING
// ============================================================
function startFarming($email, $password) {
    if (!doLogin($email, $password)) return;

    $membership = getAccountMembershipInfo();
    $tierName = $membership['tier'];
    $maxDailyClaims = $membership['limit'];

    $balance = getBalance();
    $dailyCount = getDailyCount();

    logMessage(WHITE, "  [TIER]", "Detected: {$tierName} (Limit: {$maxDailyClaims})", GOLD);
    logMessage(WHITE, "  [BALANCE]", "{$balance} USDT", GREEN);
    logMessage(WHITE, "  [DAILY]", "{$dailyCount}/" . $maxDailyClaims, GOLD); 
    logMessage(B_YELLOW, "  [START]", "Bot jalan...", YELLOW);
    echo YELLOW . "  ----------------------------------------\n" . RESET;

    $claims = 0; $failures = 0; $skips = 0;
    $maxFailures = 10;

    while (true) {
        if (resetDailyIfNeeded()) $dailyCount = 0;

        if ($dailyCount >= $maxDailyClaims) {
            logMessage(B_WHITE, "  [LIMIT]", "Habis kuota harian, tunggu reset.", WHITE);
            timer(strtotime('tomorrow 00:00:00') - time(), "  ⏳ Reset in: ");
            continue;
        }

        $info = [];
        $res = claimFaucet($info);

        if ($res === 'limit_reached') {
            break;
        }
        elseif ($res === 'session_invalid') {
            logMessage(B_YELLOW, "  [!]", "Session expired, tunggu 15s sebelum re-login...", YELLOW);
            sleep(15);
            if (!doLogin($email, $password)) {
                logMessage(WHITE, "  [STOP]", "Re-login gagal.", RED);
                break;
            }
            $balance = getBalance();
            logMessage(WHITE, "  [BALANCE]", "{$balance} USDT", GREEN);
            logMessage(WHITE, "  [INFO]", "tunggu 20s sebelum lanjut...", GRAY);
            sleep(20);
            continue;
        }
        elseif ($res === 'captcha_skip') {
            $skips++;
            logMessage(B_YELLOW, "  [SKIP]", "skip round", YELLOW);
            humanDelayTimer(rand(10, 15));
        }
        elseif ($res === 'no_form' || $res === 'no_csrf') {
            logMessage(B_YELLOW, "  [INFO]", "form kosong, tunggu 5s", YELLOW);
            sleep(5);
        }
        elseif ($res === 'fetch_fail') {
            $failures++;
            logMessage(WHITE, "  [FAIL]", "fetch fail ({$failures}/{$maxFailures})", RED);
            if ($failures >= $maxFailures) {
                logMessage(WHITE, "  [STOP]", "Gagal terus.", RED);
                break;
            }
            sleep(20);
        }
        elseif ($res === 'ad_token_fail') {
            $failures++;
            logMessage(WHITE, "  [FAIL]", "ad token fail ({$failures}/{$maxFailures})", RED);
            if ($failures >= $maxFailures) {
                logMessage(WHITE, "  [STOP]", "Gagal terus.", RED);
                break;
            }
            sleep(15);
        }
        elseif (is_array($res) && isset($res['cooldown'])) {
            $cd = $res['cooldown'];
            logMessage(B_YELLOW, "  [COOLDOWN]", "{$cd}s", YELLOW);
            timer($cd, "  ⏳ Cooldown: ");
        }
        elseif ($res === true) {
            $claims++; $dailyCount++;
            updateDailyCount($dailyCount);
            $failures = 0;
            $balance = getBalance();
            
            echo WHITE . "  [BALANCE] " . B_GREEN;
            printType($balance . " USDT", 30000);
            echo WHITE . " | Daily: " . GOLD . "{$dailyCount}/" . $maxDailyClaims . WHITE . " | Total: " . GOLD . "{$claims}\n" . RESET;
            
            humanDelayTimer(rand(14, 19));
        }
        else {
            $failures++;
            logMessage(WHITE, "  [FAIL]", "{$failures}/{$maxFailures}", RED);
            if ($failures >= $maxFailures) {
                logMessage(WHITE, "  [STOP]", "Gagal terus.", RED);
                break;
            }
            humanDelayTimer(rand(10, 15));
        }
    }

    $balance = getBalance();
    echo CYAN . "\n  [FINAL] " . WHITE . $balance . " USDT | Total Claims: " . GOLD . "{$claims}\n" . RESET;
}

// ============================================================
//  MENU INTERAKTIF
// ============================================================
function printMenu() {
    printBanner("Auto Detect", 1500);
    $termwidth = 44;
    $b1 = "========================================";

    echo CYAN . "  [1] " . GREEN . "Start Farming\n";
    echo CYAN . "  [2] " . YELLOW . "Config Email & Password\n";
    echo CYAN . "  [0] " . RED . "Exit\n";
    echo GOLD . "  " . $b1 . "\n" . RESET;
    echo WHITE . "  Pilih menu: " . RESET;
}

function configEmailPassword() {
    printBanner("Setup", 100);
    echo WHITE . "  Email    : " . RESET;
    $e = trim(fgets(STDIN));
    echo WHITE . "  Password : " . RESET;
    $p = trim(fgets(STDIN));

    file_put_contents(CONFIG_FILE, json_encode(['email'=>$e, 'password'=>$p], JSON_PRETTY_PRINT));
    logMessage(B_GREEN, "  ✅", "Konfigurasi berhasil disimpan!", GREEN);
    echo WHITE . "  Tekan Enter untuk kembali...\n" . RESET;
    fgets(STDIN);
}

// ============================================================
//  MAIN EXECUTION
// ============================================================
if (!file_exists(CONFIG_FILE)) {
    logMessage(B_YELLOW, "  [!]", "Config belum ada. Silakan isi dulu.", YELLOW);
    echo WHITE . "  Tekan Enter untuk lanjut...\n" . RESET;
    fgets(STDIN);
    configEmailPassword();
}

$cfg = json_decode(file_get_contents(CONFIG_FILE), true);
$email = $cfg['email'] ?? '';
$password = $cfg['password'] ?? '';

while (true) {
    printMenu();
    $choice = trim(fgets(STDIN));

    switch ($choice) {
        case '1':
            printBanner("Connecting...", 1500);
            logMessage(B_YELLOW, "  [START]", "Bot dimulai... (Tekan CTRL+C untuk berhenti)", YELLOW);
            echo YELLOW . "  ----------------------------------------\n" . RESET;
            startFarming($email, $password);
            echo WHITE . "\nTekan Enter untuk kembali...\n" . RESET;
            fgets(STDIN);
            break;
        case '2':
            configEmailPassword();
            $cfg = json_decode(file_get_contents(CONFIG_FILE), true);
            $email = $cfg['email'] ?? '';
            $password = $cfg['password'] ?? '';
            break;
        case '0':
            logMessage(GREEN, "  ✨", "Terima kasih! Sampai jumpa.", GREEN);
            exit(0);
        default:
            logMessage(RED, "  ❌", "Pilihan tidak valid!", RED);
            echo WHITE . "  Tekan Enter untuk melanjutkan...\n" . RESET;
            fgets(STDIN);
    }
}
