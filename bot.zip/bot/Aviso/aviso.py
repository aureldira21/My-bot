import requests
import time
import re
import json
import random
from bs4 import BeautifulSoup
from datetime import datetime
from colorama import init, Fore, Style
import sys

# Inisialisasi colorama
init(autoreset=True)

# Format pasangannya: (User-Agent, Nilai Sec-CH-UA-Version)
USER_AGENTS_POOL = [
    (
        "Mozilla/5.0 (Linux; Android 13; SM-S901B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36",
        '"Chromium";v="112", "Google Chrome";v="112", "Not:A-Brand";v="99"'
    ),
    (
        "Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Mobile Safari/537.36",
        '"Chromium";v="111", "Google Chrome";v="111", "Not:A-Brand";v="99"'
    ),
    (
        "Mozilla/5.0 (Linux; Android 11; Redmi Note 10 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Mobile Safari/n110",
        '"Chromium";v="110", "Google Chrome";v="110", "Not:A-Brand";v="99"'
    ),
    (
        "Mozilla/5.0 (Linux; Android 13; ONEPLUS A6013) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36",
        '"Chromium";v="113", "Google Chrome";v="113", "Not:A-Brand";v="99"'
    ),
    (
        "Mozilla/5.0 (Linux; Android 12; M2101K6G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36",
        '"Chromium";v="112", "Google Chrome";v="112", "Not:A-Brand";v="99"'
    )
]

class AvisoBot:
    def __init__(self, phpses):
        self.session = requests.Session()
        self.base_url = "https://aviso.bz"
        
        selected_ua, sec_ch_ua_val = random.choice(USER_AGENTS_POOL)
        
        self.headers = {
            "authority": "aviso.bz",
            "cache-control": "max-age=0",
            "sec-ch-ua": sec_ch_ua_val,
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": '"Android"',
            "upgrade-insecure-requests": "1",
            "user-agent": selected_ua,
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "sec-fetch-site": "same-origin",
            "sec-fetch-mode": "navigate",
            "sec-fetch-user": "?1",
            "sec-fetch-dest": "document",
            "referer": "https://aviso.bz/settings?s=social-network",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
        }
        
        self.cookies = {"PHPSESSID": phpses}
        self.session.cookies.update(self.cookies)
        self.sid = None
        self.task_completed_count = 0
        self.break_threshold = random.randint(7, 12)

    def generate_tab_id(self):
        chars = "abcdefghijklmnopqrstuvwxyz0123456789"
        return "".join(random.choice(chars) for _ in range(25))

    def get_tasks(self):
        print(Fore.YELLOW + Style.BRIGHT + f"🔍 [{datetime.now().strftime('%H:%M:%S')}] Mengambil daftar tugas...")
        try:
            res = self.session.get(f"{self.base_url}/tasks-youtube", headers=self.headers, timeout=15)
            
            sid_match = re.search(r"sid\s*=\s*'([^']+)'", res.text)
            if sid_match:
                self.sid = sid_match.group(1)
            
            soup = BeautifulSoup(res.text, 'html.parser')
            tables = soup.find_all("table", id=re.compile(r"ads-link-"))
            
            task_ids = []
            for table in tables:
                tid = table.get('id').replace('ads-link-', '')
                task_ids.append(tid)
            
            print(Fore.GREEN + Style.BRIGHT + f"🎉 Tugas {len(task_ids)} Ditemukan! Lagi Nonton.")
            return task_ids
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
            print(Fore.RED + "❌ Koneksi terputus/timeout. Menunggu 30 detik untuk pemulihan...")
            time.sleep(30)
            return []
        except Exception as e:
            print(Fore.RED + f"❌ Error get_tasks: {e}")
            return []

    def start_task(self, task_id):
        tab_id = self.generate_tab_id()
        url = f"{self.base_url}/go/create-task-view.php?id={task_id}&show_popup_for_cookie=yes&tabId={tab_id}&show-notify=yes"
        
        try:
            res = self.session.get(url, headers=self.headers)
            data = {}
            for key in ['reportId', 'taskId', 'hash', 'videoId', 'timer']:
                match = re.search(rf"{key}:\s*\"([^\"]+)\"", res.text)
                if match:
                    data[key] = match.group(1)
            if data.get('taskId'):
                return data
        except Exception as e:
            print(Fore.RED + f"❌ Error start_task {task_id}: {e}")
        return None

    def simulate_interval(self, task_id):
        url = f"{self.base_url}/ajax/intervalView.php"
        payload = {
            "createIntervalView": "true",
            "campaign_id": task_id,
            "type_work": "youtube_view",
            "view_ccx": random.randint(150, 680),
            "view_ccy": random.randint(300, 950),
            "view_pcx": random.randint(150, 680),
            "view_pcy": random.randint(300, 950),
            "view_it": "true",
            "time": int(time.time() * 1000)
        }
        try:
            self.session.post(url, data=payload, headers=self.headers)
        except: pass

    def complete_task(self, task_data):
        url = f"{self.base_url}/ajax/earnings/ajax-youtube-external.php"
        payload = {
            "hash": task_data['hash'],
            "sid": self.sid,
            "task_id": task_data['taskId'],
            "report_id": task_data['reportId'],
            "video_id": task_data['videoId'],
            "timer": task_data['timer']
        }
        
        headers = self.headers.copy()
        headers["x-requested-with"] = "XMLHttpRequest"
        headers["content-type"] = "application/x-www-form-urlencoded; charset=UTF-8"
        
        try:
            res = self.session.post(url, data=payload, headers=headers)
            return res.json()
        except Exception as e:
            pass
        return None

    def run(self):
        while True:
            task_ids = self.get_tasks()
            
            if not task_ids:
                time.sleep(5)
                continue
            
            if len(task_ids) <= 2:
                random_break = random.randint(300, 540)
                print(Fore.WHITE + Style.BRIGHT + f"\n🚨 PENTING! Sisa 2 Tugas Bot Istirahat Dulu Bre.. ({random_break} detik)")
                time.sleep(random_break)
                continue
                
            for index, task_id in enumerate(task_ids):
                sisa_tugas_sekarang = len(task_ids) - index
                if sisa_tugas_sekarang <= 2:
                    random_break = random.randint(300, 540)
                    print(Fore.WHITE + Style.BRIGHT + f"\n🚨 PENTING! Sisa 2 Tugas Bot Istirahat Dulu Bre.. ({random_break} detik)")
                    time.sleep(random_break)
                    break

                if self.task_completed_count >= self.break_threshold:
                    break_time = random.randint(20, 45)
                    print(Fore.BLUE + Style.BRIGHT + f"\n☕Istirahat selama {break_time} detik agar terlihat manusiawi...")
                    time.sleep(break_time)
                    self.task_completed_count = 0
                    self.break_threshold = random.randint(7, 12)

                task_data = self.start_task(task_id)
                if task_data:
                    timer = int(task_data['timer'])
                    print(Fore.CYAN + f"🎬 Tugas ID: {task_id} | Video: {task_data['videoId']} | Timer: {timer}s")
                    print(Fore.YELLOW + Style.BRIGHT + "👀 Sedang Menonton Video...")
                    
                    self.simulate_interval(task_id)
                    
                    for i in range(timer, -1, -1):
                        print(Fore.WHITE + Style.BRIGHT + f"\r⏳ Menunggu {i} detik... ", end="", flush=True)
                        if i > 0:
                            time.sleep(random.uniform(0.9, 1.2))
                            if i % 5 == 0: self.simulate_interval(task_id)
                    print(Fore.GREEN + Style.BRIGHT + "Done! ✅")
                    
                    human_delay = random.uniform(1.5, 4.5)
                    time.sleep(human_delay)
                    
                    result = self.complete_task(task_data)
                    if result and result.get('error') == False:
                        html_content = result.get('html', '')
                        reward_match = re.search(r"<b>([\d.]+)</b>", html_content)
                        reward = reward_match.group(1) if reward_match else "N/A"
                        
                        sisa_setelah_claim = sisa_tugas_sekarang - 1
                        
                        print(Fore.GREEN + Style.BRIGHT + f"💰 Sukses! Reward: {reward} rub. | 📋 Sisa Tugas: {sisa_setelah_claim}")
                        self.task_completed_count += 1
                    else:
                        print(Fore.RED + f"❌ Gagal: {result}")
                    
                    delay = random.randint(5, 15)
                    time.sleep(delay)
                else:
                    pass
            
            print(Fore.YELLOW + Style.BRIGHT + "\n🔄 Putaran selesai, mengecek ulang tugas...")
            time.sleep(random.randint(3, 8))

if __name__ == "__main__":
    print(Fore.CYAN + Style.BRIGHT + "==================================================")
    print(Fore.CYAN + Style.BRIGHT + "         🤖 AVISO BY Team JENDELA SEMESTA  🤖         ")
    print(Fore.CYAN + Style.BRIGHT + "            SEMOGA GAK KEBAN HAHAA!!              ")
    print(Fore.CYAN + Style.BRIGHT + "==================================================")
    print(Fore.YELLOW + Style.BRIGHT + "Warning : JANGAN DIPAKAI TERLALU SERING")
    print(Fore.GREEN + Style.BRIGHT + "Note    : Resiko Ditanggung Sendiri Ya Bre")
    print(Fore.CYAN + Style.BRIGHT + "==================================================")
    
    phpses_input = input(Fore.WHITE + Style.BRIGHT + "🔑 masukan phpses id : ")
    
    bot = AvisoBot(phpses_input)
    bot.run()
