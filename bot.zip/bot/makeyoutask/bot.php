<?php

error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
$configFile = "config.json";
$waryono = "cookies.txt";

const hitam  = "\033[0;30m";
const merah  = "\033[0;31m";
const hijau  = "\033[0;32m";
const kuning = "\033[0;33m";
const biru   = "\033[0;34m";
const cyan   = "\033[0;36m";
const putih  = "\033[0;37m";
const reset  = "\033[0m";
const bg_hitam  = "\033[40m";
const bg_merah  = "\033[41m";
const bg_hijau  = "\033[42m";
const bg_kuning = "\033[43m";
const bg_biru   = "\033[44m";
const bg_ungu   = "\033[45m";
const bg_cyan   = "\033[46m";
const bg_putih  = "\033[47m";

const version     = "1.0";
const script_name = "makeyoutask.com";
const host        = "https://makeyoutask.com";
const in      = "https://api.waryono.my.id/in.php";

// Fungsi untuk teks biasa tanpa animasi
function print_fast($text) {
    echo $text . "\n";
}

// Fungsi animasi ketik diubah ke 0,02 detik (20000 mikrosekon)
function print_typing($text, $speed = 20000) {
    for ($i = 0; $i < mb_strlen($text); $i++) {
        echo mb_substr($text, $i, 1);
        usleep($speed);
    }
    echo "\n";
}

function device_token_init() {
    $file = "device_token.txt";
    if (file_exists($file)) {
        $tok = trim(file_get_contents($file));
        if ($tok !== '') {
            return $tok;
        }
    }
    $screen_data = '1080x1920x24';
    $nav_data = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36' . 'id-ID' . '1';
    $raw = $screen_data . $nav_data . time() . mt_rand();
    $hash = 0;
    for ($i = 0, $l = strlen($raw); $i < $l; $i++) {
        $hash = (($hash << 5) - $hash) + ord($raw[$i]);
        $hash &= 0xFFFFFFFF;
    }
    $tok = 'dev_' . abs($hash) . '_' . substr(bin2hex(random_bytes(4)), 0, 8);
    file_put_contents($file, $tok);
    return $tok;
}

function clear() {
    (PHP_OS == "Linux") ? system('clear') : pclose(popen('cls', 'w'));
}

function ensure_device_cookie($host) {
    global $device_token;
    $file = "cookies.txt";
    if (!file_exists($file) || !$host) {
        return;
    }
    $content = file($file);
    foreach ($content as $line) {
        if (strpos($line, "\t".$host."\t") !== false && strpos($line, "\tdevice_token\t") !== false) {
            return;
        }
    }
    file_put_contents($file, $host."\tFALSE\t/\tFALSE\t4102444800\tdevice_token\t".$device_token."\n", FILE_APPEND);
}

function smm_claim_headers($claim_url, $referer) {
    $origin = preg_replace('~^(https?://[^/]+).*$~', '$1', $claim_url);
    $headers = [
        'sec-ch-ua: "Not;A=Brand";v="8", "Chromium";v="127", "Google Chrome";v="127"',
        'sec-ch-ua-platform: "Android"',
        'x-requested-with: XMLHttpRequest',
        'user-agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
        'accept: application/json, text/javascript, q=0.01',
        'content-type: application/x-www-form-urlencoded; charset=UTF-8',
        'sec-ch-ua-mobile: ?1',
        'origin: '.$origin,
        'sec-fetch-site: same-origin',
        'sec-fetch-mode: cors',
        'sec-fetch-dest: empty'
    ];
    if ($referer) {
        $headers[] = 'referer: '.$referer;
    }
    $headers[] = 'accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7';
    return $headers;
}

function blog_headers($referer, $is_post = false) {
    $origin = preg_replace('~^(https?://[^/]+).*$~', '$1', $referer);
    $headers = [
        'sec-ch-ua: "Chromium";v="127", "Not)A;Brand";v="99", "Microsoft Edge Simulate";v="127", "Lemur";v="127"',
        'sec-ch-ua-mobile: ?1',
        'sec-ch-ua-platform: "Android"',
        'upgrade-insecure-requests: 1',
        'user-agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
        'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,q=0.8,application/signed-exchange;v=b3;q=0.7',
        'sec-fetch-site: same-origin',
        'sec-fetch-mode: navigate',
        'sec-fetch-user: ?1',
        'sec-fetch-dest: document',
        'accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
    ];
    if ($is_post) {
        array_unshift($headers, 'cache-control: max-age=0');
        array_unshift($headers, 'content-type: application/x-www-form-urlencoded');
        array_unshift($headers, 'origin: '.$origin);
    }
    if ($referer) {
        $headers[] = 'referer: '.$referer;
    }
    return $headers;
}

function skibidixxx($url, $method = 'GET', $data = [], $headers = [], $nofollow = false) {
    while (true) {
        $ch = curl_init();
        $final_headers = [];
        foreach ($headers as $header) {
            $final_headers[] = $header;
        }
        $options = [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => true,
            CURLOPT_SSL_VERIFYHOST => 1,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER     => $final_headers,
            CURLOPT_CONNECTTIMEOUT => 999,
            CURLOPT_TIMEOUT        => 999,
            CURLOPT_COOKIEFILE => 'cookies.txt',
            CURLOPT_COOKIEJAR => 'cookies.txt'
        ];
        if (!$nofollow) {
            $options[CURLOPT_FOLLOWLOCATION] = true;
        }
        if (strtoupper($method) === 'POST') {
            $options[CURLOPT_POST] = true;
            $options[CURLOPT_POSTFIELDS] = $data;
        }
        curl_setopt_array($ch, $options);
        $response = curl_exec($ch);
        if ($response) {
            $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
            $body = substr($response, $header_size);
            $eff = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
            $GLOBALS['last_url'] = $eff;
            $eff_host = parse_url($eff, PHP_URL_HOST);
            if ($eff_host && strpos($eff_host, 'makeyoutask.com') === false) {
                ensure_device_cookie($eff_host);
            }
            curl_close($ch);
            return $body;
        } else {
            curl_close($ch);
            echo "\33[1;" . rand(30, 37) . "mwiwok detok";
            sleep(1);
            echo "\r \r";
            return "ngelek";
        }
    }
}

function timer($seconds, $prefix = "[!] please wait") {
    $wait_time = (int)$seconds;
    $frames = ['⣾', '⣽', '⣻', '⢿', '⡿', '⣟', '⣯', '⣷'];
    $frame_count = count($frames);
    $current_frame = 0;
    $frame_delay = 0.1;
    while ($wait_time > 0) {
        $start_time = microtime(true);
        while ((microtime(true) - $start_time) < 1) {
            $hours = floor($wait_time / 3600);
            $minutes = floor(($wait_time % 3600) / 60);
            $seconds_left = $wait_time % 60;
            $time_formatted = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds_left);
            $spinner = $frames[$current_frame];
            echo putih . $prefix . hijau . " $time_formatted " . putih . $spinner . "\r";
            usleep($frame_delay * 1000000);
            $current_frame = ($current_frame + 1) % $frame_count;
            if ((microtime(true) - $start_time) >= 1) {
                break;
            }
        }
        $wait_time--;
    }
    echo "\r                                     \r";
}

function tampilkanPesanSukses($pesan_asli, $header_b, $watched_time = null) {
    preg_match('/([\d\.]+)\s*Token/i', $pesan_asli, $t1);
    $token_utama = $t1[1] ?? '0';

    preg_match('/Ptc\s*Earning\s*([\d\.]+)/i', $pesan_asli, $t2);
    $ptc_earning = $t2[1] ?? '0';

    preg_match('/Level\s*Bonus\s*([\d\.]+)/i', $pesan_asli, $t3);
    $lvl_bonus = $t3[1] ?? '0';

    preg_match('/([\d\.]+)\s*Energy/i', $pesan_asli, $t4);
    $energy = $t4[1] ?? '0';

    $dash = skibidixxx(host."/dashboard", "GET", [], $header_b);
    preg_match('/<span class="stat-number text-success">([^<]+)<\/span>/', $dash, $bal);
    $current_balance = trim($bal[1] ?? 'Unknown');

    print_typing(hijau . "✅️ Sukses!  " . kuning . $token_utama . hijau . " Token ditambahkan" . reset);
    print_typing(hijau . "✅️ Sukses!  " . kuning . $ptc_earning . hijau . " Token ptc ditambahkan" . reset);
    print_typing(hijau . "✅️ Level  Bonus " . kuning . $lvl_bonus . hijau . "  Energy " . kuning . $energy . reset);
    print_typing(putih . "📌 All Has  Been  Added  To  Your  Balance." . reset);
    print_typing(putih . "💰 Current Balance : " . biru . $current_balance . reset);
    print_fast(putih . "------------------------------------------" . reset);
}

function getConfig($configFile) {
    if (!file_exists($configFile)) {
        echo putih . "API Key   : " . kuning;
        $apikey = trim(fgets(STDIN));
        echo putih . "Email     : " . kuning;
        $email = trim(fgets(STDIN));
        echo putih . "Password  : " . kuning;
        $password = trim(fgets(STDIN));
        $data = [
            "apikey"   => $apikey,
            "email"    => $email,
            "password" => $password
        ];
        file_put_contents($configFile, json_encode($data, JSON_PRETTY_PRINT));
        print_fast(hijau . "Konfigurasi disimpan ke $configFile\n" . reset);
        sleep(2);
        return $data;
    }
    return json_decode(file_get_contents($configFile), true);
}

function cloud($apikey, $sitekey, $cdata = '', $domain = host) {
    $headers = ["Content-Type: application/json"];
    $body = json_encode([
        "apikey"  => $apikey,
        "methods" => "turnstile",
        "domain"  => $domain,
        "sitekey" => $sitekey,
        "action"  => "submit",
        "cdata"   => $cdata,
        "json"    => 1
    ]);
    $request = skibidixxx(in, "POST", $body, $headers);
    if (strpos($request, "ERROR_WRONG_METHOD") !== false)              { print_fast(putih."Error: ".merah."ERROR_WRONG_METHOD"); exit; }
    if (strpos($request, "ERROR_KEY_DOES_NOT_EXIST") !== false)        { print_fast(putih."Error: ".merah."ERROR_KEY_DOES_NOT_EXIST"); exit; }
    if (strpos($request, "ERROR_METHOD_NOT_SPECIFIED") !== false)      { print_fast(putih."Error: ".merah."ERROR_METHOD_NOT_SPECIFIED"); exit; }
    if (strpos($request, "ERROR_NO_SUCH_METHOD") !== false)            { print_fast(putih."Error: ".merah."ERROR_NO_SUCH_METHOD"); exit; }
    if (strpos($request, "ERROR_DATABASE_CONNECTION_FAILED") !== false){ print_fast(putih."Error: ".merah."ERROR_DATABASE_CONNECTION_FAILED"); exit; }
    if (strpos($request, "ERROR_TOO_MANY_REQUESTS") !== false) {
        print_fast(putih."Error: ".merah."ERROR_TOO_MANY_REQUESTS");
        sleep(1.2);
        return "ERROR_TOO_MANY_REQUESTS";
    }
    if (strpos($request, "ERROR_WRONG_USER_KEY") !== false)  { print_fast(putih."Error: ".merah."ERROR_WRONG_USER_KEY"); exit; }
    if (strpos($request, "ERROR_ZERO_BALANCE") !== false)    { print_fast(putih."Error: ".merah."ERROR_ZERO_BALANCE"); exit; }
    if (strpos($request, "ERROR_BAD_PARAMETERS") !== false)  { print_fast(putih."Error: ".merah."ERROR_BAD_PARAMETERS"); exit; }
    if (strpos($request, "ERROR_EMPTY_IMAGE") !== false)     { print_fast(putih."Error: ".merah."ERROR_EMPTY_IMAGE"); exit; }
    if (strpos($request, "ERROR_UNKNOWN") !== false)         { print_fast(putih."Error: ".merah."ERROR_UNKNOWN"); exit; }

    $json = json_decode($request, true);
    $id   = $json["request"];

    reload_cf:
    timer(3, "  cf");
    $url    = "https://api.waryono.my.id/res.php?apikey=".$apikey."&action=get&id=".$id."&json=1";
    $result = skibidixxx($url, "GET", []);

    if (strpos($result, "ERROR_BAD_PARAMETERS") !== false)        { print_fast(putih."Error: ".merah."ERROR_BAD_PARAMETERS"); exit; }
    if (strpos($result, "Database connection failed") !== false)   { print_fast(putih."Error: ".merah."Database connection failed"); exit; }
    if (strpos($result, "WRONG_CAPTCHA_ID") !== false) {
        print_fast(putih."Error: ".merah."WRONG_CAPTCHA_ID");
        sleep(1.2);
        return "WRONG_CAPTCHA_ID";
    }
    if (strpos($result, "ERROR_SOLVE_PENDING") !== false) {
        print_fast(putih."Error: ".merah."ERROR_SOLVE_PENDING");
        sleep(1.2);
        return "ERROR_SOLVE_PENDING";
    }
    if (strpos($result, "CAPCHA_NOT_READY") !== false) {
        print_fast(putih."(Menunggu solver...)");
        sleep(2);
        goto reload_cf;
    }
    if (strpos($result, "ERROR_CAPTCHA_UNSOLVABLE") !== false) {
        print_fast(putih."Error: ".merah."ERROR_CAPTCHA_UNSOLVABLE");
        sleep(1.2);
        return "ERROR_CAPTCHA_UNSOLVABLE";
    }
    if (strpos($result, "ERROR_BAD_REQUEST") !== false)    { print_fast("Error: ".merah."ERROR_BAD_REQUEST"); exit; }
    if (strpos($result, "INTENAL_SERVER_ERROR") !== false) {
        print_fast("Error: ".merah."INTENAL_SERVER_ERROR");
        sleep(1.2);
        return "INTENAL_SERVER_ERROR";
    }

    $json = json_decode($result, true);
    $res  = $json["request"];
    return ["turnstile" => $res];
}

function allsuki(&$a,&$b,&$c,&$d){
	$a = [
		'host: '.script_name,
		'sec-ch-ua: "Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
		'sec-ch-ua-platform: "Android"',
		'save-data: on',
		'upgrade-insecure-requests: 1',
		'user-agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
		'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,q=0.8,application/signed-exchange;v=b3;q=0.7',
		'sec-fetch-site: none',
		'sec-fetch-mode: navigate',
		'sec-fetch-user: ?1',
		'sec-fetch-dest: document',
		'accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
	];
	$b = [
		'host: '.script_name,
		'sec-ch-ua: "Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
		'sec-ch-ua-platform: "Android"',
		'save-data: on',
		'origin: '.host,
		'content-type: application/x-www-form-urlencoded',
		'upgrade-insecure-requests: 1',
		'user-agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
		'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,q=0.8,application/signed-exchange;v=b3;q=0.7',
		'sec-fetch-site: same-origin',
		'sec-fetch-mode: navigate',
		'sec-fetch-user: ?1',
		'sec-fetch-dest: document',
		'referer: '.host.'/login',
		'accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
	];
	$c = [
		'host: makeyoutask.com',
		'sec-ch-ua: "Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
		'sec-ch-ua-platform: "Android"',
		'user-agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
		'origin: '.host,
		'sec-fetch-site: same-origin',
		'sec-fetch-mode: cors',
		'sec-fetch-dest: empty',
		'referer: '.host.'/dashboard',
		'accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
	];
	$d = [
		'host: '.script_name,
		'sec-ch-ua: "Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"',
		'sec-ch-ua-platform: "Android"',
		'sec-ch-ua-mobile: ?1',
		'upgrade-insecure-requests: 1',
		'user-agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
		'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
		'sec-fetch-site: same-origin',
		'sec-fetch-mode: navigate',
		'sec-fetch-user: ?1',
		'sec-fetch-dest: document',
		'referer: '.host.'/dashboard',
		'accept-language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
	];
}
home:
clear();
$config   = getConfig($configFile);
$apikey   = $config['apikey'];
$email    = $config['email'];
$password = $config['password'];

clear();
$device_token = device_token_init();

allsuki($a,$b,$c,$d);
$url = host."/dashboard";
$dash = skibidixxx($url, "GET", [], $b);
if (strpos($dash, "Dashboard | MakeYouTask.Com") !== false){
	preg_match('/<span class="font-weight-bold text-white">([^<]+)<\/span>/', $dash, $user);
	$username = trim($user[1] ?? 'Guest');
	preg_match('/>LVL\s+(\d+)<\/span>/', $dash, $lvl);
	$level = trim($lvl[1] ?? '0');
	$level = "Level ".$level;
	preg_match('~font-weight: 700; color: #fff;">\s*([\d.,]+)\s*\/\s*([\d.,]+)\s*</div>~s', $dash, $exp);
	$current_exp = trim(($exp[1] ?? '0')." / ".($exp[2] ?? '0'));
	preg_match('/<span class="stat-number text-success">([^<]+)<\/span>/', $dash, $bal);
	$balance = trim($bal[1] ?? '0 Token');
	print_fast(putih."user: ".cyan.$username.putih." balance: ".biru.$balance);
	print_fast(putih."level: ".biru.$level.putih." (".biru.$current_exp.putih.")\n");

	print_fast(putih."[INFO] ".kuning."Mengambil informasi jumlah tugas tersedia...");

	$check_smm = skibidixxx(host."/SmmNew/watch", "GET", [], $d);
	$smm_count = (preg_match('/let\s+videoCode/', $check_smm)) ? "Tersedia" : "Kosong/Cooldown";

	$check_yt = skibidixxx(host."/ptc", "GET", [], $a);
	preg_match_all('~href="(https?://[^"]+/single/[^"]+)"~', $check_yt, $res_yt);
	$yt_count = count($res_yt[1] ?? []);

	$check_win = skibidixxx(host."/ptc/index/window", "GET", [], $a);
	preg_match_all('/wmv-url="([^"]+)"/', $check_win, $res_win);
	$win_count = count($res_win[1] ?? []);

	$check_ifr = skibidixxx(host."//ptc/index/iframe", "GET", [], $a);
	preg_match_all("/window\.location\s*=\s*'([^']+)'/", $check_ifr, $res_ifr);
	$ifr_count = count($res_ifr[1] ?? []);

	clear();
	print_fast(putih."user: ".cyan.$username.putih." balance: ".biru.$balance);
	print_fast(putih."level: ".biru.$level.putih." (".biru.$current_exp.putih.")\n");

	print_fast(putih."==========================================");
	print_fast(putih."           PILIH MENU CLAIM             ");
	print_fast(putih."==========================================");
	print_fast(putih."[".hijau."1".putih."] SMM Watch & Earn  -> ".kuning.$smm_count);
	print_fast(putih."[".hijau."2".putih."] PTC YouTube       -> ".cyan.$yt_count." Task");
	print_fast(putih."[".hijau."3".putih."] PTC Window        -> ".cyan.$win_count." Task");
	print_fast(putih."[".hijau."4".putih."] PTC Iframe        -> ".cyan.$ifr_count." Task");
	print_fast(putih."[".hijau."5".putih."] Jalankan Semua (Auto Loop)");
	print_fast(putih."------------------------------------------");
	print_fast(putih."by andrekaskus");
	echo putih."Pilih menu [1-5]: ".kuning;
	$pilihan = trim(fgets(STDIN));
	echo reset;

	if ($pilihan == "1") {
	    goto smm_get;
	} elseif ($pilihan == "2") {
	    goto youtube;
	} elseif ($pilihan == "3") {
	    goto kopet;
	} elseif ($pilihan == "4") {
	    goto iframe;
	} elseif ($pilihan == "5") {
	    goto smm_get;
	} else {
	    print_fast(merah."Pilihan tidak valid! Mengulang...");
	    sleep(2);
	    goto home;
	}

	reload:
	echo "\n";
	print_fast(putih."[mission:".kuning." smm watch & earn".putih."]");
	print_fast(putih."------------------------------------------");

	smm_get:
	$url = host."/SmmNew/watch";
	$watch = skibidixxx($url, "GET", [], $d);
	$blog_page = $GLOBALS['last_url'];
	$blog_origin = preg_replace('~^(https?://[^/]+).*$~', '$1', $blog_page);

	gate_loop:
	if (strpos($watch, "solve_gate_captcha") !== false) {
	    preg_match('/name="csrf_token_name" value="([^"]+)"/', $watch, $gcs);
	    preg_match('/data-sitekey="([^"]+)"/', $watch, $gsite);
	    $gate_csrf = $gcs[1] ?? '';
	    $sitekey   = $gsite[1] ?? '';
	    if (!$gate_csrf || !$sitekey) {
	        print_fast(putih."[ERROR] ".merah."Gagal parse security gate, retry...");
	        sleep(3);
	        goto smm_get;
	    }
	    print_fast(putih."[GATE] ".kuning."Menyelesaikan security verification (turnstile)...");
	    $bypass = cloud($apikey, $sitekey, '', $blog_origin);
	    if (is_array($bypass)) {
	        $data = http_build_query([
	            "csrf_token_name" => $gate_csrf,
	            "cf-turnstile-response" => $bypass["turnstile"],
	            "solve_gate_captcha" => "1"
	        ]);
	        skibidixxx($blog_page, "POST", $data, blog_headers($blog_page, true), true);
	        $watch = skibidixxx($blog_page, "GET", [], blog_headers($blog_page));
	        $blog_page = $GLOBALS['last_url'];
	        goto gate_loop;
	    } elseif (in_array($bypass, ["WRONG_CAPTCHA_ID", "ERROR_CAPTCHA_UNSOLVABLE", "ERROR_TOO_MANY_REQUESTS", "ERROR_SOLVE_PENDING", "INTENAL_SERVER_ERROR"])) {
	        goto gate_loop;
	    } else {
	        print_fast(putih."Error: ".merah." Tidak di ketahui!! coba lagi...");
	        goto gate_loop;
	    }
	}

	if (!preg_match('/let\s+videoCode/', $watch)) {
	    if (strpos($watch, "There are no videos available for you right now") !== false) {
	        print_fast(putih."[INFO] ".kuning."No video available right now, lanjut ke misi berikutnya...");
	        goto ptc;
	    }
	    if (strpos($watch, "You must wait at least") !== false) {
	        preg_match('~at least <strong>(\d+)\s*minutes?</strong>~i', $watch, $mnt);
	        $menit = intval($mnt[1] ?? 5);
	        timer($menit * 60, "  cooldown...");
	        goto smm_get;
	    }
	    if (strpos($watch, "Human Verification Required") !== false) {
	        print_fast(putih."[ERROR] ".merah."Halaman minta verifikasi tapi gak ada videoCode, retry...");
	        sleep(3);
	        goto smm_get;
	    }
	    if (preg_match('/<title>([^<]+)<\/title>/', $watch, $ttl)) {
	        print_fast(putih."[ERROR] ".merah."Halaman: ".kuning.trim($ttl[1]));
	    }
	    if (preg_match('/class="wat-(msg-box|limit-card|security-card)[^"]*"[^>]*>(.{0,300})/s', $watch, $wbox)) {
	        $txt = trim(strip_tags($wbox[2]));
	        print_fast(putih."[ERROR] ".merah."Pesan: ".kuning.substr($txt, 0, 200));
	    }
	    if (strpos($watch, "login") !== false && strpos($watch, "MakeYouTask") === false) {
	        print_fast(putih."[ERROR] ".merah."Session mungkin expired (login required).");
	    }
	    print_fast(putih."[ERROR] ".merah."Gagal membuka halaman stream, retry...");
	    sleep(3);
	    goto smm_get;
	}

	preg_match("/let csrfHash = '([^']+)';/", $watch, $csh);
	preg_match('/let requiredTime = (\d+);/', $watch, $rt);
	preg_match('/let targetDuration = (\d+);/', $watch, $td);
	preg_match("/let videoCode = '([^']+)';/", $watch, $vc);
	preg_match("~url:\s*'([^']*claim_watch/\d+)'~", $watch, $cw);
	$csrf_hash = $csh[1] ?? '';
	$required  = intval($rt[1] ?? 60);
	$target    = intval($td[1] ?? 0);
	$vid       = $vc[1] ?? '?';
	$claim_url = $cw[1] ?? '';
	if ($claim_url && strpos($claim_url, 'http') !== 0) {
	    $claim_url = $blog_origin . $claim_url;
	}
	if (!$csrf_hash || !$claim_url) {
	    print_fast(putih."[ERROR] ".merah."Data stream tidak lengkap!");
	    sleep(3);
	    goto smm_get;
	}
	if ($target > 0) {
	    $total_claim = ceil($target / $required);
	    print_fast(putih."video: ".biru.$vid.putih." | target: ".biru.$target."s".putih." | claim tiap: ".biru.$required."s".putih." (~".$total_claim."x)");
	} else {
	    print_fast(putih."video: ".biru.$vid.putih." | mode baru (s/d refresh:true) | claim tiap: ".biru.$required."s");
	}

	if (strpos($watch, "Human Verification Required") !== false) {
	    preg_match('/data-sitekey="([^"]+)"/', $watch, $site);
	    $sitekey = $site[1] ?? '';
	    preg_match("~url:\s*'([^']*verify_start_captcha)'~", $watch, $vsc);
	    $verify_url = $vsc[1] ?? '';
	    if (!$sitekey || !$verify_url || !$csrf_hash) {
	        print_fast(putih."[ERROR] ".merah."Gagal parse human verification!");
	        sleep(3);
	        goto smm_get;
	    }
	    smm_verify:
	    $bypass = cloud($apikey, $sitekey);
	    if (is_array($bypass)) {
	        $data = http_build_query([
	            "captcha" => "turnstile",
	            "cf-turnstile-response" => $bypass["turnstile"],
	            "csrf_token_name" => $csrf_hash
	        ]);
	        $verify = skibidixxx($verify_url, "POST", $data, smm_claim_headers($verify_url, $blog_page));
	        preg_match('/"status"\s*:\s*"([^"]*)"/', $verify, $st);
	        preg_match('/"message"\s*:\s*"((?:[^"\\\\]|\\\\.)*)"/', $verify, $ms);
	        preg_match('/"csrf_token"\s*:\s*"([^"]*)"/', $verify, $tk);
	        if (!empty($tk[1])) {
	            $csrf_hash = $tk[1];
	        }
	        $status = $st[1] ?? '';
	        $pesan  = isset($ms[1]) ? stripslashes($ms[1]) : 'Invalid response';
	        if ($status == 'success') {
	            print_fast(putih."[VERIFY] ".hijau.$pesan);
	        } else {
	            print_fast(putih."[VERIFY] ".merah.$pesan);
	            sleep(2);
	            goto smm_verify;
	        }
	    } elseif (in_array($bypass, ["WRONG_CAPTCHA_ID", "ERROR_CAPTCHA_UNSOLVABLE", "ERROR_TOO_MANY_REQUESTS", "ERROR_SOLVE_PENDING", "INTENAL_SERVER_ERROR"])) {
	        goto smm_verify;
	    } else {
	        print_fast(putih."Error: ".merah." Tidak di ketahui!! coba lagi...");
	        goto smm_verify;
	    }
	}

	$watched = 0;
	while (true) {
	    timer($required, "  watching [".$vid."]");
	    $watched += $required;
	    $done = ($target > 0 && $watched >= $target);
	    $data = http_build_query(["csrf_token_name" => $csrf_hash]);
	    $claim = skibidixxx($claim_url, "POST", $data, smm_claim_headers($claim_url, $blog_page));
	    preg_match('/"status"\s*:\s*"([^"]*)"/', $claim, $st);
	    preg_match('/"message"\s*:\s*"((?:[^"\\\\]|\\\\.)*)"/', $claim, $ms);
	    preg_match('/"csrf_token"\s*:\s*"([^"]*)"/', $claim, $tk);
	    preg_match('/"refresh"\s*:\s*(true|false)/', $claim, $rf);
	    preg_match('/"captcha"\s*:\s*(true|false)/', $claim, $cp);
	    $status = $st[1] ?? '';
	    $pesan  = isset($ms[1]) ? stripslashes($ms[1]) : 'Invalid response';
	    if (!empty($tk[1])) {
	        $csrf_hash = $tk[1];
	    }
	    if ($status == 'success') {
	        $bersih = trim(str_replace(['<br>', '<br/>', '<br />'], ' ', strip_tags($pesan)));
	        tampilkanPesanSukses($bersih, $b);
	    } else {
	        print_fast(putih."[".biru.$watched."s".putih."] ".merah.$pesan);
	        print_fast(putih."------------------------------------------");
	    }
	    if (($cp[1] ?? 'false') == 'true') {
	        print_fast(putih."[ERROR] ".merah."hubungi admin untuk update script.");
	        break;
	    }
	    if (($rf[1] ?? 'false') == 'true' || $done) {
	        break;
	    }
	}
	print_fast(putih."[INFO] ".kuning."Selesai... next video");
	goto smm_get;

	ptc:
	echo "\n";
	print_fast(putih."[mission:".kuning." ptc youtube".putih."]");
	print_fast(putih."------------------------------------------");

	youtube:
	$url = host."/ptc";
	$ptc = skibidixxx($url, "GET", [], $a);
	preg_match_all('~href="(https?://[^"]+/single/[^"]+)"~', $ptc, $res);
	$url_view = $res[1][0] ?? '';
	if ($url_view) {
	    $xhamters = skibidixxx($url_view, "GET", [], $a);
	    preg_match('/const countdownTime = (\d+);/', $xhamters, $tmr);
	    $wait = intval($tmr[1] ?? 0);
	    preg_match('~action="(https?://[^"]+/ptc/verify/\d+)"~', $xhamters, $act);
	    $action = $act[1] ?? '';
	    preg_match('/data-sitekey="([^"]+)"/', $xhamters, $site);
	    $sitekey = $site[1] ?? '';
	    preg_match('/name="csrf_token_name"\s+value="([^"]+)"/', $xhamters, $csrf);
	    $token = $csrf[1] ?? '';
	    if (!$action || !$token || !$sitekey) {
	        print_fast(putih."[ERROR] ".merah."Gagal parse halaman video!");
	        sleep(2);
	        goto youtube;
	    }
	    timer($wait, "  watching...");

	    nyaha:
	    $bypass = cloud($apikey, $sitekey);
	    if (is_array($bypass)) {
	        $data = http_build_query([
	            "captcha" => "turnstile",
	            "cf-turnstile-response" => $bypass["turnstile"],
	            "csrf_token_name" => $token
	        ]);
	        $claim = skibidixxx($action, "POST", $data, $b);
	        if (preg_match("/html:\s*'([^']+)'/", $claim, $msg)) {
	            $pesan = trim(str_replace(['<br>', '<br/>', '<br />'], ' ', strip_tags($msg[1])));
	            tampilkanPesanSukses($pesan, $b);
	            goto youtube;

	        } elseif (preg_match("/Swal\.fire\('[^']+',\s*'([^']+)',\s*'success'\)/s", $claim, $msg)) {
	            $pesan = trim(str_replace(['<br>', '<br/>', '<br />'], ' ', strip_tags($msg[1])));
	            tampilkanPesanSukses($pesan, $b);
	            goto youtube;

	        } else {
	            print_fast(putih."[INFO] ".merah."Error task or captcha");
	            print_fast(putih."------------------------------------------");
	            goto youtube;
	        }

	    } elseif (in_array($bypass, ["WRONG_CAPTCHA_ID", "ERROR_CAPTCHA_UNSOLVABLE", "ERROR_TOO_MANY_REQUESTS", "ERROR_SOLVE_PENDING", "INTENAL_SERVER_ERROR"])) {
	        goto nyaha;

	    } else {
	        print_fast(putih."Error: ".merah." Tidak di ketahui!! coba lagi...");
	        goto youtube;
	    }
	} else {
	    if ($pilihan == "5") {
	        goto winptc;
	    }
	}

	winptc:
	echo "\n";
	print_fast(putih."[mission:".kuning." ptc window".putih."]");
	print_fast(putih."------------------------------------------");

	kopet:
	$url = host."/ptc/index/window";
	$ptc = skibidixxx($url, "GET", [], $a);
	preg_match_all('/wmv-url="([^"]+)"\s*wmv-sec="(\d+)"/', $ptc, $res);
	$url_view = $res[1][0] ?? '';
	$detik    = $res[2][0] ?? 0;
	if ($url_view) {
		$go = skibidixxx($url_view, "GET", [], $a);
		timer($detik, "  watching...");
		$url = host."/ptc/getCaptcha";
		$getCaptcha = skibidixxx($url, "GET", [], $a);
		preg_match('/name="csrf_token_name" value="([^"]+)"/', $getCaptcha, $csrf);
		$token = $csrf[1] ?? '';
		preg_match('/data-sitekey="([^"]+)"/', $getCaptcha, $site);
		$sitekey = $site[1] ?? '';

		tai:
		$bypass = cloud($apikey, $sitekey);
		if (is_array($bypass)) {
		$url = host."/ptc/verifyWindow";
		$data = http_build_query([
			  "csrf_token_name" => $token,
			  "captcha" => "turnstile",
			  "cf-turnstile-response" => $bypass["turnstile"]
		]);
		$claim = skibidixxx($url, "POST", $data, $b);
		if (preg_match("/html:\s*'([^']+)'/", $claim, $msg)) {
		    $pesan = trim(str_replace(['<br>', '<br/>', '<br />'], ' ', strip_tags($msg[1])));
		    tampilkanPesanSukses($pesan, $b);
		    goto kopet;

		} elseif (preg_match("/Swal\.fire\('[^']+',\s*'([^']+)',\s*'success'\)/", $claim, $msg)) {
		    $pesan = trim(str_replace(['<br>', '<br/>', '<br />'], ' ', strip_tags($msg[1])));
		    tampilkanPesanSukses($pesan, $b);
		    goto kopet;

		} else {
		    print_fast(putih."[INFO] " . merah . "Error captcha or expired task");
		    print_fast(putih."------------------------------------------");
		    goto kopet;
		}

	} elseif (in_array($bypass, ["WRONG_CAPTCHA_ID", "ERROR_CAPTCHA_UNSOLVABLE", "ERROR_TOO_MANY_REQUESTS", "ERROR_SOLVE_PENDING", "INTENAL_SERVER_ERROR"])) {
		  goto tai;
		
	} else {
	  print_fast(putih."Error: ".merah." Tidak di ketahui!! coba lagi...");
	  goto kopet;
}
				
	} else {
	  print_fast(putih."[INFO] ".putih."Tugas tidak tersedia!");
	  if ($pilihan == "5") {
	      goto iframe;
	  }

	}	

	iframe:
	echo "\n";
	print_fast(putih."[mission:".kuning." ptc iframe".putih."]");
	print_fast(putih."------------------------------------------");
	coli:
	$url = host."//ptc/index/iframe";
	$iframe = skibidixxx($url, "GET", [], $a);
	preg_match_all("/window\.location\s*=\s*'([^']+)'/", $iframe, $res);
	$url_view = $res[1][0] ?? '';
	if ($url_view) {
		$xhamters = skibidixxx($url_view, "GET", [], $a);
		preg_match('/action="([^"]+ptc\/verify\/[^"]+)"/', $xhamters, $act);
		$action = $act[1] ?? '';
		preg_match('/data-sitekey="([^"]+)"/', $xhamters, $site);
		$sitekey = $site[1] ?? '';
		preg_match('/name="csrf_token_name" value="([^"]+)"/', $xhamters, $csrf);
		$token = $csrf[1] ?? '';
		preg_match('/var timer = (\d+);/', $xhamters, $tmr);
		$wait = $tmr[1] ?? 0;
		timer($wait, "  watching...");

		nyawit:
		$bypass = cloud($apikey, $sitekey);
		if (is_array($bypass)) {
			$data = http_build_query([
				  "captcha" => "turnstile",
				  "cf-turnstile-response" => $bypass["turnstile"],
				  "csrf_token_name" => $token
			]);
		$claim = skibidixxx($action, "POST", $data, $b);
		if (preg_match("/Swal\.fire\('[^']+',\s*'([^']+)',\s*'success'\)/s", $claim, $msg)) {
		    $pesan = trim(str_replace(['<br>', '<br/>', '<br />'], ' ', strip_tags($msg[1])));
		    tampilkanPesanSukses($pesan, $b);
		    goto coli;

		} else {
		    print_fast(putih."[INFO] " . merah . "Error Task Or captcha");
		    print_fast(putih."------------------------------------------");
		    goto coli;
		}
		
		} elseif (in_array($bypass, ["WRONG_CAPTCHA_ID", "ERROR_CAPTCHA_UNSOLVABLE", "ERROR_TOO_MANY_REQUESTS", "ERROR_SOLVE_PENDING", "INTENAL_SERVER_ERROR"])) {
			  goto nyawit;
		
    } else {
		  print_fast(putih."Error: ".merah." Tidak di ketahui!! coba lagi...");
		  goto coli;
	 }
		
	} else {
	    print_fast(kuning . "\nSEMUA TUGAS TIDAK TERSEDIA!" . reset);
	    timer(7, "Kembali ke menu awal dalam");
	    goto home;
	}
	
} else {
allsuki($a,$b,$c,$d);
	print_fast(kuning."login required...!");

	ulang:
	$url = host."/login";
	$login = skibidixxx($url, "GET", [], $a);
	preg_match('/action="([^"]+auth\/login)"/', $login, $act);
	$action = $act[1] ?? '';
	preg_match('/name="csrf_token_name" value="([^"]+)"/', $login, $csrf);
	$token = $csrf[1] ?? '';
	preg_match('/data-sitekey="([^"]+)"/', $login, $site);
	$sitekey = $site[1] ?? '';
	$bypass = cloud($apikey, $sitekey);
	if (is_array($bypass)) {
	$data = http_build_query([
		  "csrf_token_name" => $token,
		  "email" => $email,
		  "password" => $password,
		  "captcha" => "turnstile",
		  "cf-turnstile-response" => $bypass["turnstile"]
	]);
	$login = skibidixxx($action, "POST", $data, $b);
	if (preg_match('/Dashboard \| MakeYouTask\.Com/i', $login)) {
	    print_fast(putih."[INFO] ".hijau."Login Success, go -> Dashboard.");
	    sleep(2);
	    goto home;
	    
	} elseif (preg_match('/alert-danger">.*?<\/i>\s*([^<]+)/s', $login, $fail)) {
	    print_fast(putih."[INFO] ".merah.trim($fail[1]));
	    @unlink($waryono);
	    @unlink($configFile);
	    exit;
	} else {
	    print_fast(putih."[INFO] ".kuning."Error tidak diketahui, mungkin Cloudflare atau IP Block!");
	    @unlink($waryono);
	    @unlink($configFile);
	    exit;
	}

	} elseif (in_array($bypass, ["WRONG_CAPTCHA_ID", "ERROR_CAPTCHA_UNSOLVABLE", "ERROR_TOO_MANY_REQUESTS", "ERROR_SOLVE_PENDING", "INTENAL_SERVER_ERROR"])) {
	  goto ulang;

    } else {
	  print_fast(putih."Error: ".merah." Tidak di ketahui!! coba lagi...");
	  goto ulang;
 }

}
