<?php

error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
$configFile = "config.json";

const hitam  = "\033[0;30m";
const merah  = "\033[0;31m";
const hijau  = "\033[0;32m";
const kuning = "\033[0;33m";
const biru   = "\033[0;34m";
const cyan   = "\033[0;36m";
const putih  = "\033[0;37m";
const reset  = "\033[0m";

const api_url    = "https://mini.keran.co/api.php";
const solver_in  = "https://api.waryono.my.id/in.php";
const solver_out = "https://api.waryono.my.id/res.php";
const SITEKEY = "0x4AAAAAAACAEtFrYI5hvlhN";

$HEADERS = [
    'sec-ch-ua: "Not=A?Brand";v="99", "Android WebView";v="151", "Chromium";v="151"',
    'sec-ch-ua-platform: "Android"',
    'sec-ch-ua-mobile: ?1',
    'user-agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.7922.199 Mobile Safari/537.36 Telegram-Android/12.9.1 (Xiaomi M2006C3LG; Android 10; SDK 29; AVERAGE)',
    'content-type: application/json',
    'origin: https://mini.keran.co',
    'x-requested-with: org.telegram.messenger.web',
    'sec-fetch-site: same-origin',
    'sec-fetch-mode: cors',
    'sec-fetch-dest: empty',
    'referer: https://mini.keran.co/',
    'accept-language: en,id-ID;q=0.9,id;q=0.8,en-US;q=0.7'
];

function clear() {
    (PHP_OS == "Linux") ? system('clear') : pclose(popen('cls', 'w'));
}

function timer($seconds, $prefix = "[!] please wait") {
    $wait_time = (int)$seconds;
    if ($wait_time < 1) {
        return;
    }
    $frames = ['⣾', '⣽', '⣻', '⢿', '⡿', '⣟', '⣯', '⣷'];
    $frame_count = count($frames);
    $current_frame = 0;
    $frame_delay = 0.1;
    while ($wait_time > 0) {
        $start_time = microtime(true);
        while ((microtime(true) - $start_time) < 1) {
            $hours = floor($wait_time / 3600);
            $minutes = floor(($wait_time % 3600) / 60);
            $seconds_left = $wait_time % 60;
            $time_formatted = sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds_left);
            $spinner = $frames[$current_frame];
            echo putih . $prefix . hijau . " $time_formatted " . putih . $spinner . "\r";
            usleep($frame_delay * 1000000);
            $current_frame = ($current_frame + 1) % $frame_count;
            if ((microtime(true) - $start_time) >= 1) {
                break;
            }
        }
        $wait_time--;
    }
    echo "\r                                     \r";
}

function getConfig($configFile) {
    if (!file_exists($configFile)) {
        echo putih . "API Key (captcha solver) : " . kuning;
        $apikey = trim(fgets(STDIN));
        echo putih . "initData (TG WebView) : " . kuning;
        $initData = trim(fgets(STDIN));
        echo putih . "deviceId (64 hex) : " . kuning;
        $deviceId = trim(fgets(STDIN));
        echo putih . "coupon_code (kosongkan jika tidak ada) : " . kuning;
        $coupon = trim(fgets(STDIN));
        $data = [
            "apikey"   => $apikey,
            "initData" => $initData,
            "deviceId" => $deviceId,
            "coupon_code" => $coupon
        ];
        file_put_contents($configFile, json_encode($data, JSON_PRETTY_PRINT));
        echo hijau . "Konfigurasi disimpan ke $configFile\n\n" . reset;
        sleep(2);
        return $data;
    }
    return json_decode(file_get_contents($configFile), true);
}

function wkwk($url, $payload = null, $headers = [], $method = "POST") {
    while (true) {
        $ch = curl_init();
        $final = [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYHOST => 1,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_CONNECTTIMEOUT => 999,
            CURLOPT_TIMEOUT        => 999,
            CURLOPT_COOKIEFILE     => 'cookies.txt',
            CURLOPT_COOKIEJAR      => 'cookies.txt'
        ];
        if ($method === "POST") {
            $final[CURLOPT_POST] = true;
            $final[CURLOPT_POSTFIELDS] = json_encode($payload);
        }
        curl_setopt_array($ch, $final);
        $response = curl_exec($ch);
        curl_close($ch);
        if ($response) {
            return $response;
        }
        echo putih . "\nwiwok detok, retry...\n";
        sleep(2);
    }
}

function api_call($action, $initData, $deviceId, $extra = []) {
    $payload = array_merge([
        "action"   => $action,
        "initData" => $initData,
        "deviceId" => $deviceId
    ], $extra);
    $res = wkwk(api_url, $payload, $GLOBALS['HEADERS']);
    return json_decode($res, true);
}

function solve_captcha($apikey, $action) {
    while (true) {
        $headers = ["Content-Type: application/json"];
        $body = [
            "apikey"  => $apikey,
            "methods" => "turnstile",
            "domain"  => "https://mini.keran.co",
            "sitekey" => SITEKEY,
            "action"  => $action,
            "cdata"   => "",
            "json"    => 1
        ];
        $request = wkwk(solver_in, $body, $headers);
        foreach (["ERROR_WRONG_METHOD", "ERROR_KEY_DOES_NOT_EXIST", "ERROR_NO_SUCH_METHOD", "ERROR_WRONG_USER_KEY", "ERROR_ZERO_BALANCE", "ERROR_BAD_PARAMETERS", "ERROR_UNKNOWN"] as $e) {
            if (strpos($request, $e) !== false) {
                echo putih . "Error: " . merah . $e . "\n";
                exit;
            }
        }
        if (strpos($request, "ERROR_TOO_MANY_REQUESTS") !== false) {
            sleep(2);
            continue;
        }
        $id = (json_decode($request, true))["request"];

        reload:
        timer(5, "  captcha...");
        $result = wkwk(solver_out . "?apikey=" . $apikey . "&action=get&id=" . $id . "&json=1", null, [], "GET");
        if (strpos($result, "CAPCHA_NOT_READY") !== false) {
            goto reload;
        }
        $json = json_decode($result, true);
        $tok = $json["request"] ?? "";
        if (is_string($tok) && strlen($tok) > 50 && strpos($tok, ".") !== false) {
            return $tok;
        }
        sleep(3);
        goto reload;
    }
}

function fetch_user() {
    global $initData, $deviceId;
    return api_call("get_user_data", $initData, $deviceId);
}

function show_banner($data) {
    echo "\n";
    echo putih . "balance: " . biru . ($data['balance'] ?? '?') . " " . strtoupper($data['preferred_coin'] ?? '') . putih . " | today: " . biru . ($data['earned_today'] ?? '?') . putih . " | games: " . biru . ($data['faucet_global_games_started_user'] ?? 0) . "/" . ($data['faucet_global_daily_limit_user'] ?? 0) . "\n";
}

function daily_checkin($data = null) {
    global $initData, $deviceId;
    if (!$data) {
        $u = fetch_user();
        $data = (isset($u['status']) && $u['status'] == 'success') ? $u['data'] : null;
    }
    if (!$data) {
        echo putih . "[DAILY] " . merah . "gagal get_user_data\n";
        return;
    }
    $streak = $data['daily_streak'] ?? [];
    if (empty($streak['can_checkin'])) {
        echo putih . "[DAILY] " . kuning . "belum waktunya check-in (day " . ($streak['checkin_day'] ?? '?') . ")\n";
        return;
    }
    echo putih . "[DAILY] " . kuning . "check-in day " . ($streak['checkin_day'] ?? '?') . "...\n";
    $ds = api_call("claim_daily_streak", $initData, $deviceId);
    if (($ds['status'] ?? '') == 'success') {
        $sdata = $ds['data'] ?? [];
        echo putih . "[DAILY] " . hijau . "OK reward: " . ($sdata['reward_amount'] ?? '?') . " " . ($sdata['reward_coin'] ?? '') . "\n";
        if (!empty($sdata['completed_now'])) {
            echo putih . "[DAILY] " . cyan . "Siklus selesai! bonus " . ($sdata['cycle_bonus_amount'] ?? '?') . "\n";
        }
    } else {
        echo putih . "[DAILY] " . merah . ($ds['message'] ?? 'error') . "\n";
    }
}

function referral_claim($data = null) {
    global $initData, $deviceId;
    if (!$data) {
        $u = fetch_user();
        $data = (isset($u['status']) && $u['status'] == 'success') ? $u['data'] : null;
    }
    if (!$data) {
        echo putih . "[REF] " . merah . "gagal get_user_data\n";
        return;
    }
    if (floatval($data['referral_balance'] ?? 0) <= 0) {
        echo putih . "[REF] " . kuning . "saldo referral 0\n";
        return;
    }
    echo putih . "[REF] " . kuning . "claim earnings " . $data['referral_balance'] . "...\n";
    $ref = api_call("claim_referral_earnings", $initData, $deviceId);
    if (($ref['status'] ?? '') == 'success') {
        echo putih . "[REF] " . hijau . ($ref['message'] ?? 'OK') . "\n";
    } else {
        echo putih . "[REF] " . merah . ($ref['message'] ?? 'error') . "\n";
    }
}

function coupon_redeem($code = '', $data = null) {
    global $initData, $deviceId;
    if (!$data) {
        $u = fetch_user();
        $data = (isset($u['status']) && $u['status'] == 'success') ? $u['data'] : null;
    }
    if ($data) {
        $coupon = $data['daily_coupon'] ?? [];
        if (empty($coupon['has_coupon'])) {
            echo putih . "[COUPON] " . kuning . "tidak ada coupon tersedia hari ini\n";
            return;
        }
        if (!empty($coupon['redeemed'])) {
            echo putih . "[COUPON] " . kuning . "coupon sudah di-redeem\n";
            return;
        }
    }
    if ($code === '') {
        echo putih . "Kode coupon: " . kuning;
        $code = trim(fgets(STDIN));
        if ($code === '') {
            echo putih . "batal.\n";
            return;
        }
    }
    echo putih . "[COUPON] " . kuning . "redeem " . $code . "...\n";
    $cp = api_call("redeem_daily_coupon", $initData, $deviceId, ["coupon_code" => $code]);
    if (($cp['status'] ?? '') == 'success') {
        echo putih . "[COUPON] " . hijau . ($cp['message'] ?? 'OK') . "\n";
    } else {
        echo putih . "[COUPON] " . merah . ($cp['message'] ?? 'error') . "\n";
    }
}

function do_daily_rewards($data) {
    daily_checkin($data);
    referral_claim($data);
    if (trim($GLOBALS['coupon_code'] ?? '') !== '') {
        coupon_redeem($GLOBALS['coupon_code'], $data);
        $GLOBALS['coupon_done'] = true;
    }
}

function claim_all_game() {
    global $apikey, $initData, $deviceId;
    $MODES = ["meteor", "card", "roll", "wheel", "box", "target", "scratch", "chest"];
    $mode_idx = -1;

    clear();
    echo putih . "[mini.keran.co " . kuning . "claim all game" . putih . "]\n";
    echo putih . "------------------------------------------\n";
    echo putih . "[MODE] " . cyan . "Rotasi 8 game sampai daily limit. Ctrl+C untuk stop.\n";

    while (true) {
        $user = fetch_user();
        if (!isset($user['status']) || $user['status'] != 'success') {
            echo putih . "[DATA] " . merah . ($user['message'] ?? json_encode($user)) . "\n";
            timer(60, "  retry...");
            continue;
        }
        $data = $user['data'];
        show_banner($data);

        if (($data['faucet_global_games_started_user'] ?? 0) >= ($data['faucet_global_daily_limit_user'] ?? 999999)) {
            echo putih . "[INFO] " . merah . "Daily limit tercapai (" . ($data['faucet_global_games_started_user'] ?? 0) . "/" . ($data['faucet_global_daily_limit_user'] ?? 0) . ").\n";
            return;
        }

        $post_cooldown = intval($data['post_claim_cooldown_remaining'] ?? 0);
        if ($post_cooldown > 0) {
            timer($post_cooldown, "  post-claim cooldown...");
            continue;
        }

        $mode = null;
        $spin = null;
        $min_wait = 999999;
        for ($k = 0; $k < count($MODES); $k++) {
            $mode_idx = ($mode_idx + 1) % count($MODES);
            $candidate = $MODES[$mode_idx];
            if (($data['faucet_daily_limit_reached_' . $candidate] ?? false)) {
                continue;
            }
            $try = api_call("get_faucet_spin_reward", $initData, $deviceId, ["mode" => $candidate]);
            if (isset($try['status']) && $try['status'] == 'success') {
                $mode = $candidate;
                $spin = $try;
                break;
            }
            $msg = $try['message'] ?? json_encode($try);
            $remain = intval($try['cooldown_remaining'] ?? 0);
            if ($remain > 0 && $remain < $min_wait) {
                $min_wait = $remain;
            }
            if (strpos($msg, "Too many requests") !== false) {
                sleep(15);
            } else {
                sleep(3);
            }
        }
        if (!$mode || !$spin) {
            if ($min_wait >= 999999) {
                $min_wait = 60;
            }
            echo putih . "semua mode cooldown/limit, tunggu " . kuning . $min_wait . "s\n";
            timer($min_wait, "  waiting mode...");
            continue;
        }

        $gameToken = $spin['gameToken'] ?? '';

        $attempts = 0;
        dbl_start:
        $dbl = api_call("start_double_reward", $initData, $deviceId, ["mode" => $mode, "gameToken" => $gameToken]);
        if (isset($dbl['status']) && $dbl['status'] == 'success') {
            $challenge = $dbl['challenge'] ?? '';
            $nb = intval($dbl['not_before'] ?? 0);
            $wait = $nb - time();
            if ($wait > 0) {
                timer($wait, "  not_before...");
            }

            $tok1 = solve_captcha($apikey, "double_reward");
            $comp = api_call("complete_double_reward", $initData, $deviceId, [
                "mode"         => $mode,
                "gameToken"    => $gameToken,
                "adProof"      => "",
                "challenge"    => $challenge,
                "captchaToken" => $tok1
            ]);
            if (isset($comp['status']) && $comp['status'] == 'success') {
            } else {
                echo putih . "[COMP] " . merah . ($comp['message'] ?? 'error') . "\n";
                sleep(5);
            }
        } else {
            $dmsg = $dbl['message'] ?? 'error';
            if (strpos($dmsg, "Too many requests") !== false && $attempts < 3) {
                $attempts++;
                echo putih . "[DBL] " . merah . $dmsg . ", coba lagi (" . $attempts . "/3)...\n";
                timer(20, "  retry dbl...");
                goto dbl_start;
            }
            echo putih . "[DBL] " . kuning . $dmsg . "\n";
        }

        $tok2 = solve_captcha($apikey, "faucet_claim");
        $claim = api_call("claim_faucet", $initData, $deviceId, [
            "mode"         => $mode,
            "gameToken"    => $gameToken,
            "captchaToken" => $tok2
        ]);
        if (!isset($claim['status']) || $claim['status'] != 'success') {
            echo putih . "[CLAIM] " . merah . ($claim['message'] ?? json_encode($claim)) . "\n";
            timer(60, "  retry...");
            continue;
        }
        $mult = ($claim['double_applied'] ?? false) ? ($claim['double_reward_multiplier'] ?? 2) : 1;
        $g_now = intval($data['faucet_global_games_started_user'] ?? 0) + 1;
        $g_max = intval($data['faucet_global_daily_limit_user'] ?? 0);
        $amt = $claim['claimed_amount'] ?? '?';
        $coin = $claim['coin'] ?? '';
        if ($mult > 1) {
            echo putih . "[" . biru . $g_now . "/" . $g_max . putih . "] " . kuning . $mode . putih . " +" . hijau . $amt . " " . $coin . putih . " x" . hijau . $mult . "\n";
        } else {
            echo putih . "[" . biru . $g_now . "/" . $g_max . putih . "] " . kuning . $mode . putih . " +" . merah . $amt . " " . $coin . putih . " x1" . merah . " (no double)\n";
        }

        $cooldown = intval($claim['post_claim_cooldown_seconds'] ?? 55);
        timer($cooldown + mt_rand(2, 5), "  next claim...");
    }
}

function do_withdraw() {
    global $apikey, $initData, $deviceId;

    clear();
    $user = fetch_user();
    if (!isset($user['status']) || $user['status'] != 'success') {
        echo putih . "[DATA] " . merah . ($user['message'] ?? json_encode($user)) . "\n";
        return;
    }
    $data = $user['data'];
    $balance = $data['balance'] ?? '0';
    $pref = strtoupper($data['preferred_coin'] ?? 'DGB');

    echo putih . "[mini.keran.co " . kuning . "withdraw" . putih . "]\n";
    echo putih . "------------------------------------------\n";
    echo "\n";
    echo putih . "Method:\n";
    echo putih . "  1. Direct Wallet (ccpayment)\n";
    echo putih . "  2. FaucetPay (email)\n";
    echo putih . "  3. TON (TON Connect)\n";
    echo putih . "  0. Batal\n";
    echo putih . "pilih method: " . kuning;
    $m = trim(fgets(STDIN));

    if ($m == '1') {
        $method = 'direct';
        $min = $data['min_withdraw_direct'] ?? '?';
        $cc = $data['ccpayment_app_balance'] ?? [];
        $cc_coin = strtoupper($cc['coin'] ?? $pref);
        $coins = [$cc_coin];
        $hint = "Direct Wallet diambil dari saldo ccpayment (app balance), bukan saldo faucet";
    } elseif ($m == '2') {
        $method = 'faucetpay';
        $min = $data['min_withdraw_faucetpay'] ?? '?';
        $coins = array_map('strtoupper', $data['faucetpay_supported_coins'] ?? ['DGB', 'SOL', 'XLM', 'GRAM']);
        $hint = "FaucetPay (email)";
    } elseif ($m == '3') {
        $method = 'ton';
        $ton = $data['withdraw_limits']['ton']['TON'] ?? [];
        $min = ($ton['min'] ?? '?') . " - " . ($ton['max'] ?? '?');
        $coins = ['GRAM'];
        $hint = "TON Connect";
    } else {
        echo putih . "batal.\n";
        return;
    }

    $default_coin = in_array($pref, $coins) ? $pref : $coins[0];
    echo "\n";
    echo putih . "Saldo faucet      : " . biru . $balance . " " . $pref . "\n";
    if ($method == 'direct') {
        $cc = $data['ccpayment_app_balance'] ?? [];
        echo putih . "ccpayment app      : " . biru . ($cc['coin'] ?? '?') . putih . " | low: " . ($cc['low_for_withdrawal'] ? 'YA' : 'tidak') . " | cukup wd: " . ($cc['has_enough_for_withdrawal'] ? 'YA' : 'tidak') . "\n";
    }
    echo putih . "Min withdraw      : " . biru . $min . ($method == 'faucetpay' ? " " . $default_coin : "") . "\n";
    echo putih . "Coin tersedia     : " . cyan . implode(", ", $coins) . "\n";

    $b_num = floatval($balance);
    if ($method == 'faucetpay' && is_numeric($min) && $b_num < floatval($min)) {
        echo "\n" . putih . "[!] Saldo tidak cukup: " . merah . $balance . " " . $pref . putih . " < min " . $min . "\n";
        echo putih . "    (kalau ada saldo ccpayment/app, pilih Direct Wallet)\n";
        echo putih . "enter.." . kuning;
        fgets(STDIN);
        return;
    }
    if ($method == 'direct') {
        $cc = $data['ccpayment_app_balance'] ?? [];
        if (!empty($cc['low_for_withdrawal']) || (isset($cc['has_enough_for_withdrawal']) && !$cc['has_enough_for_withdrawal'])) {
            echo "\n" . putih . "[!] Saldo ccpayment tidak cukup untuk Direct Wallet.\n";
            echo putih . "pilih: " . kuning;
            fgets(STDIN);
            return;
        }
    }

    if ($method != 'ton') {
        echo putih . "Pilih coin [" . $default_coin . "]: " . kuning;
        $in = strtoupper(trim(fgets(STDIN)));
        $coin = ($in === '') ? $default_coin : $in;
        if (!in_array($coin, $coins)) {
            echo putih . "[!] Coin " . merah . $coin . putih . " tidak didukung method ini. Batal.\n";
            return;
        }
    } else {
        $coin = 'GRAM';
    }

    echo "\n";
    echo putih . $hint . " (" . cyan . $coin . putih . ")\n";
    echo putih . "Alamat " . $coin . ": " . kuning;
    $address = trim(fgets(STDIN));
    if ($address === '') {
        echo putih . "batal.\n";
        return;
    }

    $payload = [
        "method" => $method,
        "address" => $address,
        "coin" => $coin
    ];
    if ($coin === 'GRAM' && $method === 'ton') {
        $payload['currency'] = 'TON';
    }
    if ($coin === 'XLM' && $method == '2') {
        echo putih . "Memo XLM (opsional): " . kuning;
        $memo = trim(fgets(STDIN));
        if ($memo !== '') {
            $payload['memo'] = $memo;
        }
    }

    echo "\n";
    echo putih . "Konfirmasi withdraw:\n";
    echo putih . "  method  : " . cyan . $hint . "\n";
    echo putih . "  coin    : " . cyan . $coin . "\n";
    echo putih . "  alamat  : " . cyan . $address . "\n";
    echo putih . "Lanjut? (y/N): " . kuning;
    $ok = strtolower(trim(fgets(STDIN)));
    if ($ok !== 'y' && $ok !== 'yes') {
        echo putih . "batal.\n";
        return;
    }

    echo putih . "[CAPTCHA] " . kuning . "solving turnstile (withdraw_funds)...\n";
    $tok = solve_captcha($apikey, "withdraw_funds");
    $payload['captchaToken'] = $tok;

    echo putih . "[WITHDRAW] " . kuning . $method . " " . $coin . " -> " . $address . "\n";
    $res = api_call("withdraw_funds", $initData, $deviceId, $payload);
    if (($res['status'] ?? '') == 'success' || ($res['status'] ?? '') == 'pending') {
        echo putih . "[WITHDRAW] " . hijau . ($res['message'] ?? 'OK') . "\n";
    } else {
        echo putih . "[WITHDRAW] " . merah . ($res['message'] ?? json_encode($res)) . "\n";
    }
}

clear();
$config   = getConfig($configFile);
$apikey   = $config['apikey'];
$initData = $config['initData'];
$deviceId = $config['deviceId'];
$coupon_code = trim($config['coupon_code'] ?? '');
$coupon_done = false;

while (true) {
    clear();
    echo putih . "[mini.keran.co " . kuning . "faucet bot" . putih . "]\n";
    echo putih . "------------------------------------------\n";

    $uinfo = fetch_user();
    if (isset($uinfo['status']) && $uinfo['status'] == 'success') {
        $dinfo = $uinfo['data'];
        echo putih . "balance: " . biru . ($dinfo['balance'] ?? '?') . putih . " " . strtoupper($dinfo['preferred_coin'] ?? '') . putih . " | earned today: " . biru . ($dinfo['earned_today'] ?? '?') . "\n";
        echo putih . "games: " . biru . ($dinfo['faucet_global_games_started_user'] ?? 0) . "/" . ($dinfo['faucet_global_daily_limit_user'] ?? 0) . "\n";
    } else {
        echo putih . "balance: " . merah . "gagal fetch user data\n";
    }

    echo "\n";
    echo putih . "  1. " . cyan . "Claim All Game" . putih . " (rotasi semua game faucet)\n";
    echo putih . "  2. " . cyan . "Daily Streak Check-in\n";
    echo putih . "  3. " . cyan . "Claim Referral Earnings\n";
    echo putih . "  4. " . cyan . "Redeem Daily Coupon\n";
    echo putih . "  5. " . cyan . "Withdraw\n";
    echo putih . "  0. " . merah . "Exit\n";
    echo putih . "pilih: " . kuning;
    $opt = trim(fgets(STDIN));

    if ($opt == '1') {
        claim_all_game();
    } elseif ($opt == '2') {
        clear();
        daily_checkin();
        echo "\n" . putih . "enter untuk kembali...";
        fgets(STDIN);
    } elseif ($opt == '3') {
        clear();
        referral_claim();
        echo "\n" . putih . "enter untuk kembali...";
        fgets(STDIN);
    } elseif ($opt == '4') {
        clear();
        coupon_redeem();
        echo "\n" . putih . "enter untuk kembali...";
        fgets(STDIN);
    } elseif ($opt == '5') {
        do_withdraw();
    } elseif ($opt == '0') {
        exit;
    }
}
