from curl_cffi import requests
import json, time, re, sys, os, traceback, base64
from datetime import datetime
from urllib.parse import urljoin

# ==== CONFIG ====
HOST    = "https://1xfaucet.com"
API_IN  = "https://api.waryono.my.id/in.php"
API_RES = "https://api.waryono.my.id/res.php"
CONFIG  = "config.json"
SESSION = "session_py.json"
LOG     = "bot.log"
LOG_MAX_LINES = 500
LOG_MAX_MB    = 2

COINLYADS_BASE = "https://coinlyads.com"
COINLYADS_API  = f"{COINLYADS_BASE}/api/v1/captcha.php"

# ==== GLOBAL LIMIT ====
MAX_CONSECUTIVE_CAPTCHA_FAILURES = 10
captcha_failures = 0

def check_captcha_limit():
    if captcha_failures >= MAX_CONSECUTIVE_CAPTCHA_FAILURES:
        log(f"{RED}Too many consecutive captcha failures ({captcha_failures}).{RST}", "er")
        log(f"{RED}Stopping bot to protect your API balance.{RST}", "er")
        log(f"{YEL}Please check the website manually ASAP!{RST}", "wr")
        sys.exit(1)

def reset_captcha_failures():
    global captcha_failures
    captcha_failures = 0

def increment_captcha_failures():
    global captcha_failures
    captcha_failures += 1
    log(f"{YEL}Captcha failure count: {captcha_failures}/{MAX_CONSECUTIVE_CAPTCHA_FAILURES}{RST}", "wr")
    check_captcha_limit()

# ==== COLORS ====
BLK="\033[0;30m"; RED="\033[0;31m"; GRN="\033[0;32m"; YEL="\033[0;33m"
BLU="\033[0;34m"; MAG="\033[0;35m"; CYN="\033[0;36m"; WHT="\033[0;37m"
RST="\033[0m"
BOLD="\033[1m"

def clear():
    os.system('clear' if os.name == 'posix' else 'cls')

def get_term_width():
    try:
        return os.get_terminal_size().columns
    except Exception:
        return 40

def print_centered(text):
    term_width = get_term_width()
    clean_text = re.sub(r'\033\[[0-9;]*m', '', text)
    pad = max(0, (term_width - len(clean_text)) // 2)
    print(" " * pad + text)

def get_separator():
    term_width = get_term_width()
    width = max(50, term_width)
    return f"{YEL}" + "=" * width + f"{RST}"

def print_separator():
    print_centered(get_separator())

# ============================================================
#        MR BLANK  •  1xFAUCET AUTO BOT v2.6
# ============================================================

def banner():
    clear()
    sep = get_separator()
    b = [
        f"{YEL}{sep}{RST}",
        f"        {MAG}{BOLD}MR BLANK{RST}  {WHT}•{RST}  {CYN}1xFAUCET BOT{RST}",
        f"     {YEL}Auto Claim{RST}  {WHT}•{RST}  {YEL}Auto PTC{RST}  {WHT}•{RST}  {YEL}24/7{RST}",
        f"      {GRN}CoinlyAds BYPASS{RST}  {WHT}(no API cost){RST}",
        f"{YEL}{sep}{RST}"
    ]
    for line in b:
        print_centered(line)

def api_notice():
    sep = get_separator()
    n = [
        f"{CYN}CAPTCHA API NOTICE{RST}",
        f"{YEL}{sep}{RST}",
        f"{GRN}CoinlyAds{RST}{WHT} : local bypass (free){RST}",
        f"{WHT}Turnstile + Antibot via Waryono API{RST}",
        f"",
        f"{CYN}Provider :{RST} {WHT}api.waryono.my.id{RST}",
        f"{CYN}Balance  :{RST} {WHT}Check via Telegram bot{RST}",
        f"{YEL}{sep}{RST}"
    ]
    for line in n:
        print_centered(line)
    print()

def show_menu():
    sep = get_separator()
    m = [
        f"{CYN}PILIH MODE BOT:{RST}",
        f"{YEL}{sep}{RST}",
        f"{GRN}[1]{RST} {WHT}Claim Faucet Saja{RST}",
        f"{GRN}[2]{RST} {WHT}Claim PTC Saja{RST}",
        f"{GRN}[3]{RST} {WHT}Jalankan Semuanya (Faucet + PTC){RST}",
        f"{YEL}{sep}{RST}"
    ]
    for line in m:
        print_centered(line)
    print()
    choice = input("  ➡️ Masukkan pilihan (1/2/3): ").strip()
    return choice

# ==== LOG ROTATION ====
def trim_log():
    try:
        if not os.path.exists(LOG):
            return
        size_mb = os.path.getsize(LOG) / (1024 * 1024)
        if size_mb > LOG_MAX_MB:
            with open(LOG, "r", encoding="utf-8", errors="ignore") as f:
                lines = f.readlines()
            keep = lines[-LOG_MAX_LINES:]
            with open(LOG, "w", encoding="utf-8") as f:
                f.writelines(keep)
    except Exception:
        pass

_log_lines_since_trim = 0

def log(msg, tag="i", end="\n"):
    global _log_lines_since_trim
    icons = {
        "i":  f"{CYN}🚀{RST}",
        "ok": f"{GRN}✔{RST}",
        "er": f"{RED}✖{RST}",
        "wr": f"{YEL}⚠️{RST}",
        "in": f"{BLU}🔄{RST}",
        "cf": f"{CYN}⚙️{RST}",
        "pt": f"{GRN}✔{RST}",
        "fa": f"{YEL}🚰{RST}",
        "bi": f"{GRN}💎{RST}",
        "fr": f"{GRN}⚡{RST}",
    }
    icon = icons.get(tag, f"{CYN}🚀{RST}")
    line = f"{icon}  {msg}"
    print(line, end=end)
    sys.stdout.flush()

    try:
        ts = datetime.now().strftime("%H:%M:%S")
        with open(LOG, "a", encoding="utf-8") as f:
            plain = re.sub(r'\033\[[0-9;]*m', '', f"[{ts}] {line}")
            f.write(plain + (end if end != "\r" else "\n"))
        _log_lines_since_trim += 1
        if _log_lines_since_trim >= 200:
            _log_lines_since_trim = 0
            trim_log()
    except Exception:
        pass

# ==== CEK SALDO REALTIME ====
def fetch_and_show_balance(s):
    try:
        r = s.get(f"{HOST}/dashboard", timeout=30)
        
        m_token = re.search(r'id="headerBalanceTokens"[^>]*>\s*([^<]+)\s*</strong>', r.text)
        if not m_token:
            m_token = re.search(r'([\d,]+\.\d+)\s*tokens', r.text, re.IGNORECASE)
        tokens = m_token.group(1).strip() if m_token else '?'

        m_conv = re.search(r'id="headerBalanceConverted"[^>]*>\s*([^<]+)\s*</span>', r.text)
        if not m_conv:
            m_conv = re.search(r'(≈\s*[\d\.]+\s*BTC)', r.text, re.IGNORECASE)
        conv = m_conv.group(1).strip() if m_conv else '?'

        print(f"  Saldo.   : {tokens}")
        print(f"  Setara   : {conv}")
        print(f"{YEL}----------------------------------------{RST}")

    except Exception as e:
        log(f"{YEL}Gagal mengambil saldo realtime: {e}{RST}", "wr")

def timer(seconds, prefix="wait"):
    total = int(seconds)
    if total <= 0:
        return
    bar_len = 22
    start_time = time.time()
    while True:
        elapsed = int(time.time() - start_time)
        remaining = total - elapsed
        if remaining <= 0:
            break
        
        filled = int(bar_len * elapsed / total)
        filled = max(0, min(bar_len, filled))
        bar = "=" * filled + " " * (bar_len - filled)
        
        h = remaining // 3600
        m = (remaining % 3600) // 60
        s = remaining % 60
        ts = f"{h:02d}:{m:02d}:{s:02d}" if h > 0 else f"{m:02d}:{s:02d}"
        
        sys.stdout.write(f"  ⏳ {prefix} [{YEL}{bar}{RST}] {ts}\r")
        sys.stdout.flush()
        time.sleep(0.5)
    print(" " * 60 + "\r", end="")

def make_session():
    s = requests.Session(impersonate="chrome110")
    if os.path.exists(SESSION):
        try:
            with open(SESSION) as f:
                cookies = json.load(f)
            for name, value in cookies.items():
                s.cookies.set(name, value, domain=".1xfaucet.com")
        except Exception as e:
            log(f"{YEL}Session load failed: {e}{RST}", "wr")
    s.cookies.set("faucet_ad_click", "1", domain=".1xfaucet.com")
    return s

def save_session(s):
    try:
        with open(SESSION, "w") as f:
            json.dump(s.cookies.get_dict(), f, indent=2)
    except Exception as e:
        log(f"{YEL}Session save failed: {e}{RST}", "wr")

def check_login(s):
    try:
        r = s.get(f"{HOST}/dashboard", timeout=30)
        return "headerBalanceTokens" in r.text or "Logout" in r.text
    except Exception:
        return False

# ==== API SOLVER (Waryono) ====
def api_solve(apikey, method, payload, max_wait=120):
    data = {"apikey": apikey, "methods": method, "json": 1}
    data.update(payload)

    try:
        r = requests.post(API_IN, json=data, impersonate="chrome110", timeout=30)
        resp = r.json()
    except Exception as e:
        log(f"{RED}API submit error: {e}{RST}", "er")
        increment_captcha_failures()
        return None

    task_id = resp.get("request", "")
    if not task_id or "ERROR" in str(task_id):
        log(f"{RED}API submit rejected: {resp}{RST}", "er")
        increment_captcha_failures()
        return None

    start_time = time.time()
    poll_count = 0
    colors = [CYN, BLU, MAG]
    while time.time() - start_time < max_wait:
        time.sleep(2)
        poll_count += 1
        try:
            res = requests.get(
                f"{API_RES}?apikey={apikey}&action=get&id={task_id}&json=1",
                impersonate="chrome110", timeout=30
            ).json()
        except Exception:
            continue

        req = str(res.get("request", ""))
        if "CAPCHA_NOT_READY" in req:
            c = colors[poll_count % len(colors)]
            sys.stdout.write(f"  ⚙️ {method} {c}#{poll_count}{YEL} • Task {task_id}{RST}\r")
            sys.stdout.flush()
            continue
        if "ERROR" in req:
            print(" "*70+"\r", end="")
            log(f"{RED}{method} error: {req}{RST}", "er")
            increment_captcha_failures()
            return None

        print(" "*70+"\r", end="")
        return req

    log(f"{RED}{method} timeout after {max_wait}s • Task {task_id}{RST}", "er")
    increment_captcha_failures()
    return None

def solve_turnstile(apikey, sitekey):
    log(f"{CYN}Solving Turnstile via Waryono...{RST}", "cf")
    return api_solve(apikey, "turnstile", {
        "domain": HOST, "sitekey": sitekey, "action": "submit"
    }, max_wait=120)

def solve_antibot(apikey, main_b64, ids, imgs):
    payload = {"main": main_b64}
    for idx, img in zip(ids, imgs):
        payload[idx] = img
    return api_solve(apikey, "antibot", payload, max_wait=120)

# ==== COINLYADS ====
def start_coinlyads_session(s, key):
    url = f"{COINLYADS_API}?action=start&key={key}&viewer="
    try:
        r = s.get(url, timeout=30)
        data = r.json()
        if data.get("ok") and "session" in data:
            log(f"{GRN}CoinlyAds session: {data['session'][:10]}...{RST}", "ok")
            return data["session"]
        log(f"{YEL}Start session resp: {json.dumps(data)[:150]}{RST}", "wr")
    except Exception as e:
        log(f"{RED}Failed to start CoinlyAds session: {e}{RST}", "er")
    return None

def get_coinlyads_challenge(s):
    url = f"{COINLYADS_BASE}/captcha/captcha_gen.php?nocache={int(time.time()*1000)}"
    try:
        r = s.get(url, timeout=30)
        data = r.json()
        if data.get("ok"):
            return data
        log(f"{YEL}Challenge resp: {json.dumps(data)[:150]}{RST}", "wr")
    except Exception as e:
        log(f"{RED}Failed to fetch CoinlyAds challenge: {e}{RST}", "er")
    return None

def extract_answer_from_challenge(challenge):
    images = challenge.get("images", []) or []
    for img in images:
        img_id = str(img.get("id", ""))
        if img_id.startswith("win_"):
            return img_id
    for img in images:
        img_id = str(img.get("id", ""))
        if img_id.lower().startswith("win"):
            return img_id
    for k in ("correct", "answer", "solution", "correct_id", "answer_id"):
        if challenge.get(k):
            return challenge[k]
    return None

def verify_coinlyads(s, key, session, answer, captcha_token):
    payload = {
        "action": "verify",
        "key": key,
        "session": session,
        "captcha_answer": answer,
        "captcha_token": captcha_token
    }
    try:
        r = s.post(COINLYADS_API, data=payload, timeout=30)
        return r.json()
    except Exception as e:
        log(f"{RED}CoinlyAds verify failed: {e}{RST}", "er")
        return None

def solve_coinlyads(s, cfg, key):
    session = start_coinlyads_session(s, key)
    if not session:
        return None

    max_rounds = 5
    challenge = get_coinlyads_challenge(s)
    if not challenge:
        return None

    for round_num in range(max_rounds):
        cap_token = challenge.get("token", "")
        images = challenge.get("images", []) or []

        if not cap_token or not images:
            log(f"{RED}Invalid challenge{RST}", "er")
            return None

        answer = extract_answer_from_challenge(challenge)

        if not answer:
            log(f"{RED}No answer found in response!{RST}", "er")
            increment_captcha_failures()
            return None

        log(f"{GRN}Answer (fake captcha): {answer} | round {round_num+1}{RST}", "fr")

        result = verify_coinlyads(s, key, session, answer, cap_token)
        if not result:
            return None

        if result.get("ok") and result.get("pass_token"):
            log(f"{GRN}Pass token: {result['pass_token'][:12]}...{RST}", "ok")
            reset_captcha_failures()
            return result["pass_token"]

        if result.get("need_second") and result.get("second"):
            log(f"{YEL}Second verification, continuing...{RST}", "wr")
            challenge = result["second"]
            continue

        if result.get("retry") and result.get("next"):
            log(f"{YEL}Retry challenge...{RST}", "wr")
            challenge = result["next"]
            continue

        correct = result.get("correct_answer") or result.get("answer") or result.get("correct")
        if correct and str(correct) != str(answer):
            log(f"{YEL}Server hint: {correct}, retrying...{RST}", "wr")
            result = verify_coinlyads(s, key, session, correct, cap_token)
            if result and result.get("ok") and result.get("pass_token"):
                reset_captcha_failures()
                return result["pass_token"]

        log(f"{RED}Verify failed: {result.get('error', json.dumps(result)[:120])}{RST}", "er")
        increment_captcha_failures()
        return None

    log(f"{RED}Too many CoinlyAds rounds{RST}", "er")
    increment_captcha_failures()
    return None

# ==== CONFIG ====
def load_config():
    if not os.path.exists(CONFIG):
        print(f"{CYN}  Configuration Setup{RST}")
        print(f"{YEL}  ====================={RST}")
        print(f"{WHT}  Waryono API Key :{RST} ", end="")
        apikey = input().strip()
        print(f"{WHT}  1xfaucet Email  :{RST} ", end="")
        email = input().strip()
        print(f"{WHT}  1xfaucet Pass   :{RST} ", end="")
        password = input().strip()
        print(f"{WHT}  Max Captcha Failures (default 10) :{RST} ", end="")
        max_fails = input().strip()
        cfg = {
            "apikey": apikey,
            "email": email,
            "password": password,
            "max_captcha_failures": int(max_fails) if max_fails.isdigit() else 10
        }
        with open(CONFIG, "w") as f:
            json.dump(cfg, f, indent=2)
        log(f"{GRN}Config saved to {CONFIG}{RST}", "ok")
        time.sleep(2)
        return cfg
    with open(CONFIG) as f:
        cfg = json.load(f)
    if "max_captcha_failures" not in cfg:
        cfg["max_captcha_failures"] = 10
    return cfg

# ==== LOGIN ====
def login(s, cfg):
    log(f"{CYN}Fetching login page...{RST}", "in")
    try:
        r = s.get(f"{HOST}/login", timeout=30)
    except Exception as e:
        log(f"{RED}Request failed: {e}{RST}", "er")
        return False

    m = re.search(r'name="csrf_token_name"\s+(?:id="token"\s+)?value="([^"]+)"', r.text)
    csrf_token = m.group(1) if m else None
    m = re.search(r'data-sitekey="([^"]+)"', r.text)
    sitekey = m.group(1) if m else None

    if not sitekey or not csrf_token:
        log(f"{RED}CSRF/Sitekey not found{RST}", "er")
        return False

    turnstile = solve_turnstile(cfg['apikey'], sitekey)
    if not turnstile:
        return False

    try:
        r = s.post(f"{HOST}/auth/login", data={
            "csrf_token_name": csrf_token,
            "email": cfg['email'], "password": cfg['password'],
            "remember": "1", "captcha": "turnstile",
            "cf-turnstile-response": turnstile
        }, timeout=30)
    except Exception as e:
        log(f"{RED}POST failed: {e}{RST}", "er")
        return False

    if "Dashboard" in r.text or "headerBalanceTokens" in r.text:
        log(f"{GRN}Login successful{RST}", "ok")
        reset_captcha_failures()
        save_session(s)
        return True
    log(f"{RED}Login rejected{RST}", "er")
    return False

def ensure_login(s, cfg):
    if check_login(s):
        return True
    log(f"{YEL}Session expired, re-logging in...{RST}", "wr")
    if os.path.exists(SESSION):
        os.remove(SESSION)
    s2 = make_session()
    if login(s2, cfg):
        s.cookies.clear()
        for k, v in s2.cookies.get_dict().items():
            s.cookies.set(k, v, domain=".1xfaucet.com")
        s.cookies.set("faucet_ad_click", "1", domain=".1xfaucet.com")
        return True
    return False

# ==== PTC ====
def auto_ptc(s, cfg, csrf_faucet=None):
    log(f"{WHT}PTC{RST}", "pt")
    try:
        html = s.get(f"{HOST}/ptc", timeout=30).text
    except Exception as e:
        log(f"{RED}PTC fetch failed: {e}{RST}", "er")
        return False

    if "headerBalanceTokens" not in html and "Logout" not in html and "ptc-window-start" not in html:
        log(f"{RED}PTC session invalid{RST}", "er")
        return False

    m = re.search(r'csrfHash\s*[=:]\s*[\'"]([^\'"]+)[\'"]', html)
    csrf_ptc = m.group(1) if m else None
    if not csrf_ptc:
        csrf_ptc = s.cookies.get("csrf_cookie_name")
    if not csrf_ptc:
        csrf_ptc = csrf_faucet
    if not csrf_ptc:
        m_csrf = re.search(r'name="csrf_token_name"\s+(?:id="token"\s+)?value="([^"]+)"', html)
        csrf_ptc = m_csrf.group(1) if m_csrf else None
    if not csrf_ptc:
        log(f"{RED}PTC CSRF not found{RST}", "er")
        return False

    m = re.search(r'data-sitekey="([^"]+)"', html)
    sitekey_ptc = m.group(1) if m else None
    if not sitekey_ptc:
        log(f"{RED}PTC sitekey missing{RST}", "er")
        return False

    m = re.search(r'name="token"\s+value="([^"]+)"', html)
    ptc_token = m.group(1) if m else ''

    btn_pattern = re.compile(
        r'<button[^>]*class="[^"]*ptc-window-start[^"]*"[^>]*'
        r'data-id="([^"]+)"[^>]*'
        r'data-name="([^"]*)"[^>]*'
        r'data-timer="(\d+)"[^>]*'
        r'data-start-url="([^"]+)"[^>]*'
        r'data-verify-url="([^"]+)"',
        re.S
    )
    buttons = btn_pattern.findall(html)
    if not buttons:
        log(f"{YEL}No PTC available{RST}", "wr")
        return False

    total = len(buttons)
    log(f"{GRN}{total} PTC tasks available{RST}", "i")

    max_try = min(total, 5)
    current_csrf = csrf_ptc

    for i in range(max_try):
        ptc_id, ptc_name, ptc_timer, start_url, verify_url = buttons[i]
        ptc_timer = int(ptc_timer)
        if not start_url.startswith('http'):
            start_url = HOST + '/' + start_url.lstrip('/')
        if not verify_url.startswith('http'):
            verify_url = HOST + '/' + verify_url.lstrip('/')

        print(f"{GRN}  ✔ [{i+1}/{max_try}]{RST} {WHT}{ptc_name[:38]}{RST} {YEL}({ptc_timer}s){RST}")

        headers = {
            "X-Requested-With": "XMLHttpRequest",
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "Referer": f"{HOST}/ptc",
        }

        try:
            sr = s.post(start_url, data={"csrf_token_name": current_csrf},
                        headers=headers, timeout=30)
        except Exception as e:
            log(f"{RED}Request error: {e}{RST}", "er")
            time.sleep(3); continue

        if sr.status_code == 403:
            log(f"{YEL}403 Forbidden, waiting 15s{RST}", "wr")
            time.sleep(15)
            continue

        try:
            sj = sr.json()
        except Exception:
            resp_preview = re.sub(r'\s+', ' ', sr.text[:120])
            log(f"{RED}Start failed ({sr.status_code}): {resp_preview}{RST}", "er")
            if "login" in sr.text.lower() and "csrf_token_name" in sr.text:
                return False
            time.sleep(3); continue

        if not sj.get('success'):
            log(f"{RED}Start rejected{RST}", "er")
            time.sleep(3); continue

        current_csrf = sj.get('csrf_hash', current_csrf)
        if ptc_timer > 0:
            timer(ptc_timer, "ptc")

        turnstile = solve_turnstile(cfg['apikey'], sitekey_ptc)
        if not turnstile:
            print(f"  {RED}✖ turnstile failed{RST}")
            time.sleep(3); continue

        vd = {
            "captcha": "turnstile",
            "cf-turnstile-response": turnstile,
            "csrf_token_name": current_csrf,
            "token": ptc_token
        }
        try:
            vr = s.post(verify_url, data=vd,
                        headers={"Referer": f"{HOST}/ptc"},
                        timeout=30)
        except Exception as e:
            log(f"{RED}Verify error: {e}{RST}", "er")
            time.sleep(3); continue

        url_akhir = str(vr.url)
        redirect_ok = False
        if len(vr.history) > 0:
            for h in vr.history:
                if "/ptc/verify/" in str(h.url):
                    redirect_ok = True
                    break

        if url_akhir.rstrip('/').endswith('/ptc') or redirect_ok:
            print(f"  {GRN}✔ PTC completed{RST}")
            
            fetch_and_show_balance(s)
            
            reset_captcha_failures()
            new_csrf = s.cookies.get("csrf_cookie_name")
            if new_csrf:
                current_csrf = new_csrf
            time.sleep(5)
            return True
        else:
            m = re.search(r'class="alert[^"]*alert-danger"[^>]*>\s*(?:<i[^>]*></i>)?\s*([^<]+)', vr.text)
            msg = m.group(1).strip()[:60] if m else "rejected"
            print(f"  {RED}✖ {msg}{RST}")
            time.sleep(3); continue

    log(f"{RED}All PTC failed ({max_try} tried){RST}", "er")
    return False

# ==== FAUCET ====
def claim_faucet(s, cfg, retry_antibot=0):
    log(f"{YEL}Entering faucet...{RST}", "fa")
    try:
        html = s.get(f"{HOST}/faucet", timeout=30).text
    except Exception as e:
        log(f"{RED}Faucet fetch failed: {e}{RST}", "er")
        return False

    m = re.search(r'var\s+wait\s*=\s*(\d+)', html)
    if m:
        wait = int(m.group(1))
        if wait > 0:
            timer(wait, "wait")
            return claim_faucet(s, cfg, retry_antibot)

    m = re.search(r'(\d+)\s*/\s*(\d+)', html)
    if m and int(m.group(1)) <= 1:
        print(f"{YEL}⚠️ Tugas Faucet kosong / limit! Kembali ke menu dalam 7 detik...{RST}")
        timer(7, "kembali ke menu")
        return "LIMIT_REACHED"

    m = re.search(r'name="csrf_token_name"\s+(?:id="token"\s+)?value="([^"]+)"', html)
    csrf_token = m.group(1) if m else None

    m = re.search(r'<input[^>]+name="token"\s+value="([^"]+)"', html)
    token = m.group(1) if m else ''

    coinlyads_key = "068ff53bf62ece19c3b079c3cc807e13"
    m = re.search(r'widget\.php\?key=([a-f0-9]+)', html)
    if m:
        coinlyads_key = m.group(1)
    else:
        m = re.search(r'var KEY\s*=\s*"([^"]+)"', html)
        if m:
            coinlyads_key = m.group(1)

    ca_captcha_token = ""
    if "coinlyads" in html.lower() or "ca-captcha" in html.lower():
        log(f"{YEL}CoinlyAds Captcha detected (Fake) -> free bypass!{RST}", "fr")
        ca_captcha_token = solve_coinlyads(s, cfg, coinlyads_key)
        if not ca_captcha_token:
            log(f"{RED}Failed to solve CoinlyAds{RST}", "er")
            return False
    else:
        m = re.search(r'data-sitekey="([^"]+)"', html)
        sitekey = m.group(1) if m else None
        if sitekey:
            turnstile = solve_turnstile(cfg['apikey'], sitekey)
            if not turnstile:
                return False
            ca_captcha_token = turnstile
        else:
            log(f"{RED}Sitekey not found!{RST}", "er")
            return False

    bot_links = ""
    main_b64 = ''
    m = re.search(r'Please click on the Anti-Bot links in the following order.*?<img src="data:image/png;base64,([^"]+)"', html, re.S)
    if m: main_b64 = m.group(1)
    if not main_b64:
        m = re.search(r'class="antibotlinks"[^>]*>.*?<img[^>]+src="data:image/png;base64,([^"]+)"', html, re.S)
        if m: main_b64 = m.group(1)

    ids, imgs = [], []
    m = re.findall(r'<a href=\\"#\\" rel=\\"(\d+)\\"><img src=\\"data:image/png;base64,([^\\"]+)\\"', html, re.S)
    if m:
        ids  = [x[0] for x in m]
        imgs = [x[1] for x in m]
    if not ids:
        m = re.findall(r'<a href="#" rel="(\d+)"><img src="data:image/png;base64,([^"]+)"', html, re.S)
        if m:
            ids  = [x[0] for x in m]
            imgs = [x[1] for x in m]

    if ids and imgs and main_b64:
        log(f"{CYN}Antibot {len(ids)} images, solving...{RST}", "cf")
        anti = solve_antibot(cfg['apikey'], main_b64, ids, imgs)
        if not anti:
            log(f"{RED}Antibot failed{RST}", "er")
            return False
        bot_links = anti.replace(',', ' ').strip()
    else:
        log(f"{YEL}Skipping antibot (0 images){RST}", "wr")

    log(f"{CYN}Sending claim...{RST}", "in")
    try:
        post_data = {
            "antibotlinks": bot_links,
            "csrf_token_name": csrf_token,
            "token": token,
            "captcha": "coinlyads",
            "ca-captcha-response": ca_captcha_token
        }
        r = s.post(f"{HOST}/faucet/verify", data=post_data, timeout=30)
    except Exception as e:
        log(f"{RED}POST failed: {e}{RST}", "er")
        return False

    if "FaucetNotif" in r.text and "success" in r.text.lower():
        m = re.search(r'FaucetNotif\.modal\s*\(\s*["\']success["\']\s*,\s*["\']([^"\']+)["\']', r.text)
        msg = m.group(1) if m else 'Claim successful!'
        
        print(f"{GRN}  {BOLD}✔ {msg}{RST}")
        
        fetch_and_show_balance(s)

        reset_captcha_failures()
        return True

    elif "Invalid Anti-Bot Links" in r.text:
        increment_captcha_failures()
        if retry_antibot < 3:
            log(f"{YEL}Invalid antibot, retry ({retry_antibot+1}/3){RST}", "wr")
            time.sleep(3)
            return claim_faucet(s, cfg, retry_antibot + 1)
        else:
            log(f"{RED}Antibot failed 3x, waiting 60s{RST}", "er")
            time.sleep(60)
            return False

    elif "Please click any ad banner" in r.text:
        log(f"{YEL}Ad banner click required, setting trick cookie...{RST}", "wr")
        s.cookies.set("faucet_ad_click", "1", domain=".1xfaucet.com")
        time.sleep(3)
        return claim_faucet(s, cfg, retry_antibot)

    elif "Complete a PTC" in r.text or re.search(r'You have made \d+ faucet claims', r.text):
        print(f"{YEL}⚠️ Tugas Faucet kosong / limit! Kembali ke menu dalam 7 detik...{RST}")
        timer(7, "kembali ke menu")
        return "LIMIT_REACHED"

    else:
        m = re.search(r'class="alert[^"]*alert-danger"[^>]*>\s*(?:<i[^>]*></i>)?\s*([^<]+)', r.text)
        msg = m.group(1).strip()[:70] if m else 'Unknown error'
        if any(x in msg.lower() for x in ["captcha", "turnstile", "antibot", "bot", "coinly"]):
            increment_captcha_failures()
        log(f"{RED}{msg}{RST}", "er")
        return False

# ==== MAIN ====
def main():
    global MAX_CONSECUTIVE_CAPTCHA_FAILURES
    
    while True:
        banner()
        api_notice()
        
        mode = show_menu()
        if mode not in ["1", "2", "3"]:
            log(f"{RED}Pilihan tidak valid! Coba lagi...{RST}", "er")
            time.sleep(2)
            continue

        log(f"{CYN}Bot started (Mode: {'Faucet Saja' if mode=='1' else 'PTC Saja' if mode=='2' else 'Semuanya'}){RST}", "i")
        trim_log()
        cfg = load_config()
        MAX_CONSECUTIVE_CAPTCHA_FAILURES = cfg.get("max_captcha_failures", 10)
        log(f"{CYN}Consecutive captcha failure limit: {MAX_CONSECUTIVE_CAPTCHA_FAILURES}{RST}", "i")
        session = make_session()

        fail_count = 0
        loop_count = 0

        while True:
            loop_count += 1
            try:
                print(f"\n{MAG}Loop {CYN}#{loop_count}{RST}")

                if not ensure_login(session, cfg):
                    log(f"{RED}Login failed, waiting 60s...{RST}", "er")
                    time.sleep(60)
                    continue

                fetch_and_show_balance(session)

                result = None
                if mode == "1":
                    result = claim_faucet(session, cfg)
                elif mode == "2":
                    result = auto_ptc(session, cfg)
                    if not result:
                        log(f"{YEL}Tidak ada PTC atau gagal, menunggu 60s...{RST}", "wr")
                        time.sleep(60)
                    else:
                        time.sleep(10)
                    continue
                else:  # mode 3: Jalankan semuanya
                    result = claim_faucet(session, cfg)
                    if result == "LIMIT_REACHED":
                        break
                    auto_ptc(session, cfg)

                if result == "LIMIT_REACHED":
                    break

                if result:
                    fail_count = 0
                    time.sleep(3)
                else:
                    fail_count += 1
                    log(f"{YEL}Task failed (fail #{fail_count}){RST}", "wr")

                    if fail_count >= 3:
                        log(f"{YEL}Failed 3x, refreshing session...{RST}", "wr")
                        if os.path.exists(SESSION):
                            os.remove(SESSION)
                        session = make_session()
                        fail_count = 0

                    time.sleep(10)

            except KeyboardInterrupt:
                print(f"\n{YEL}Stopped by user.{RST}")
                save_session(session)
                return
            except Exception as e:
                log(f"{RED}FATAL: {e}{RST}", "er")
                time.sleep(30)

if __name__ == "__main__":
    main()
